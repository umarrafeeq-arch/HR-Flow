import React, { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from './firebase';
import { UserProfile } from '../types';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  isAdmin: boolean;
  isHR: boolean;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  loading: true,
  isAdmin: false,
  isHR: false,
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        // Bootstrap admin: urdigital409@gmail.com is always super_admin
        if (firebaseUser.email === 'urdigital409@gmail.com') {
          setProfile({
            uid: firebaseUser.uid,
            email: firebaseUser.email,
            name: 'Main Admin',
            role: 'super_admin'
          });
          setLoading(false);
          return;
        }

        try {
          // Check admins collection
          const adminDoc = await getDoc(doc(db, 'admins', firebaseUser.uid));
          if (adminDoc.exists()) {
            setProfile({
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              name: 'Super Admin',
              role: 'super_admin'
            });
          } else {
            // Check users collection
            const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
            if (userDoc.exists()) {
              const data = userDoc.data();
              setProfile({
                uid: firebaseUser.uid,
                email: firebaseUser.email || '',
                name: data.name,
                role: data.role,
                organizationId: data.organizationId
              });
            } else {
              setProfile(null);
            }
          }
        } catch (error) {
          console.error("Error fetching user profile:", error);
          setProfile(null);
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return (
    <AuthContext.Provider value={{ 
      user, 
      profile, 
      loading, 
      isAdmin: profile?.role === 'super_admin',
      isHR: profile?.role === 'hr'
    }}>
      {children}
    </AuthContext.Provider>
  );
};
