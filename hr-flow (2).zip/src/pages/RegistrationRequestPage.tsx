import React, { useState } from 'react';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { Building2, User, Mail, Send, ArrowLeft, CheckCircle2, Globe, Shield, Sparkles, Building } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';

export default function RegistrationRequestPage() {
  const [formData, setFormData] = useState({
    companyName: '',
    hrName: '',
    hrEmail: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await addDoc(collection(db, 'organization_requests'), {
        ...formData,
        status: 'pending',
        createdAt: serverTimestamp(),
      });
      setSubmitted(true);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'organization_requests');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFDFF] flex items-center justify-center p-4 selection:bg-indigo-100 italic selection:text-indigo-900 overflow-hidden relative">
      {/* Dynamic Backgrounds */}
      <div className="absolute top-0 right-0 p-20 opacity-[0.03] rotate-12 -mr-20 -mt-20">
        <Building className="w-96 h-96" />
      </div>
      <div className="absolute bottom-0 left-0 p-20 opacity-[0.03] -rotate-12 -ml-20 -mb-20">
        <Shield className="w-96 h-96" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="max-w-2xl w-full relative z-10"
      >
        <Link to="/login" className="inline-flex items-center gap-2 text-slate-400 hover:text-indigo-600 mb-8 transition-all font-black text-xs uppercase tracking-widest group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          <span>Back to Port</span>
        </Link>

        <div className="bg-white p-10 sm:p-16 rounded-[3rem] shadow-2xl shadow-indigo-200/20 border border-slate-100 overflow-hidden relative">
          <AnimatePresence mode="wait">
            {!submitted ? (
              <motion.div
                key="form"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="space-y-10"
              >
                <div>
                  <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mb-6 shadow-sm">
                    <Sparkles className="w-7 h-7" />
                  </div>
                  <h2 className="text-4xl font-black text-slate-900 tracking-tight leading-tight uppercase tracking-tighter">Registration Hub</h2>
                  <p className="text-slate-400 font-medium mt-2 max-w-sm">Secure your organization's spot in our next-gen HR ecosystem.</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-8">
                  <div className="grid sm:grid-cols-2 gap-8">
                    <div className="sm:col-span-2 space-y-3">
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Company Entity</label>
                      <div className="relative group">
                        <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 group-focus-within:text-indigo-600 transition-colors" />
                        <input
                          type="text"
                          required
                          value={formData.companyName}
                          onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                          className="w-full pl-12 pr-4 py-4.5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 focus:bg-white transition-all font-bold text-slate-900 placeholder:text-slate-300"
                          placeholder="e.g. Acme Tech Solutions"
                        />
                      </div>
                    </div>

                    <div className="space-y-3">
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Human Lead Name</label>
                      <div className="relative group">
                        <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 group-focus-within:text-indigo-600 transition-colors" />
                        <input
                          type="text"
                          required
                          value={formData.hrName}
                          onChange={(e) => setFormData({ ...formData, hrName: e.target.value })}
                          className="w-full pl-12 pr-4 py-4.5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 focus:bg-white transition-all font-bold text-slate-900 placeholder:text-slate-300"
                          placeholder="Your Full Name"
                        />
                      </div>
                    </div>

                    <div className="space-y-3">
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Operational Email</label>
                      <div className="relative group">
                        <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 group-focus-within:text-indigo-600 transition-colors" />
                        <input
                          type="email"
                          required
                          value={formData.hrEmail}
                          onChange={(e) => setFormData({ ...formData, hrEmail: e.target.value })}
                          className="w-full pl-12 pr-4 py-4.5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 focus:bg-white transition-all font-bold text-slate-900 placeholder:text-slate-300"
                          placeholder="hr@company.com"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="pt-6">
                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black py-5 rounded-2xl transition-all flex items-center justify-center gap-3 group shadow-2xl shadow-indigo-100/50 disabled:opacity-50 text-xs uppercase tracking-[0.2em] active:scale-[0.98]"
                    >
                      {loading ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        <>
                          <span>Dispatch Request</span>
                          <Send className="w-5 h-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                        </>
                      )}
                    </button>
                    <p className="text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-6">
                      By submitting you agree to our <span className="text-indigo-600 cursor-pointer">Terms of Operation</span>
                    </p>
                  </div>
                </form>
              </motion.div>
            ) : (
              <motion.div
                key="success"
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="text-center space-y-8"
              >
                <div className="w-24 h-24 bg-emerald-50 text-emerald-600 rounded-[2rem] flex items-center justify-center mx-auto shadow-sm border border-emerald-100">
                  <CheckCircle2 className="w-12 h-12" />
                </div>
                <div>
                  <h2 className="text-4xl font-black text-slate-900 tracking-tight uppercase tracking-tighter">Transmission Complete</h2>
                  <p className="text-slate-500 font-medium mt-4 max-w-sm mx-auto leading-relaxed">
                    Your organization profile has been successfully queued for vetting. Our administrators will contact you via email shortly.
                  </p>
                </div>
                
                <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100 space-y-4">
                   <div className="flex items-center justify-between text-[10px] font-black text-slate-400 uppercase tracking-widest">
                     <span>Current Status</span>
                     <span className="text-amber-500">Awaiting Vetting</span>
                   </div>
                   <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                     <motion.div initial={{ width: 0 }} animate={{ width: '33%' }} className="h-full bg-amber-500" />
                   </div>
                </div>

                <div className="pt-6">
                  <button
                    onClick={() => navigate('/login')}
                    className="w-full py-5 bg-slate-900 text-white font-black rounded-2xl transition-all text-xs uppercase tracking-[0.2em] shadow-xl shadow-slate-200 hover:scale-[1.02] active:scale-95"
                  >
                    Return to Mission Control
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}

