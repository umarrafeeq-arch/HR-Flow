import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot, doc, updateDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { useAuth } from '../../lib/AuthContext';
import { LeaveRequest } from '../../types';
import { CheckCircle2, XCircle, Clock, Calendar, Search, Filter, ArrowRight, User, AlertCircle, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ');
}

export default function LeaveManagement() {
  const { profile } = useAuth();
  const [requests, setRequests] = useState<LeaveRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'All' | 'Pending' | 'Approved' | 'Rejected'>('All');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (!profile?.organizationId) return;

    const q = query(
      collection(db, 'leaves'),
      where('organizationId', '==', profile.organizationId)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as LeaveRequest));
      setRequests(data.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'leaves');
      setLoading(false);
    });

    return () => unsubscribe();
  }, [profile]);

  const updateStatus = async (requestId: string, status: 'Approved' | 'Rejected') => {
    try {
      await updateDoc(doc(db, 'leaves', requestId), { status });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `leaves/${requestId}`);
    }
  };

  const filteredRequests = requests.filter(req => {
    const matchesFilter = filter === 'All' || req.status === filter;
    const matchesSearch = req.employeeName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         req.leaveType.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Approved':
        return (
          <span className="flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-600 rounded-lg text-[10px] font-black uppercase tracking-widest border border-emerald-100">
            <CheckCircle2 className="w-3 h-3" /> Approved
          </span>
        );
      case 'Rejected':
        return (
          <span className="flex items-center gap-1.5 px-3 py-1 bg-rose-50 text-rose-600 rounded-lg text-[10px] font-black uppercase tracking-widest border border-rose-100">
            <XCircle className="w-3 h-3" /> Rejected
          </span>
        );
      default:
        return (
          <span className="flex items-center gap-1.5 px-3 py-1 bg-indigo-50 text-indigo-600 rounded-lg text-[10px] font-black uppercase tracking-widest border border-indigo-100 animate-pulse">
            <Clock className="w-3 h-3" /> Pending
          </span>
        );
    }
  };

  return (
    <div className="max-w-[1600px] mx-auto space-y-10 pb-20">
      {/* Header */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-10 bg-white p-8 sm:p-10 rounded-[3rem] border border-slate-100 shadow-2xl shadow-slate-200/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-10 opacity-[0.02] pointer-events-none">
          <FileText className="w-64 h-64 text-slate-900" />
        </div>
        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-3">
            <span className="h-0.5 w-8 bg-slate-200" />
            <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.3em]">Resource Allocation</span>
          </div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tighter leading-none uppercase">Leave Requests</h1>
          <p className="text-slate-400 font-bold text-sm max-w-md">Manage and process personnel exception requests across the enterprise.</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3 relative z-10">
          <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-2xl border border-slate-100">
            {['All', 'Pending', 'Approved', 'Rejected'].map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f as any)}
                className={cn(
                  "px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                  filter === f 
                    ? "bg-slate-900 text-white shadow-lg shadow-slate-200" 
                    : "text-slate-400 hover:text-slate-900 hover:bg-white"
                )}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-10">
        <div className="lg:col-span-3 space-y-8">
          {/* Search Bar */}
          <div className="flex items-center gap-4 bg-white p-4 rounded-[2rem] border border-slate-100 shadow-xl shadow-slate-200/10">
            <div className="flex-1 flex items-center gap-4 px-6 py-2 bg-slate-50 border border-slate-100 rounded-2xl text-slate-400 focus-within:ring-8 focus-within:ring-indigo-50/50 focus-within:border-indigo-100 transition-all">
              <Search className="w-5 h-5" />
              <input 
                type="text" 
                placeholder="Search requests by personnel or code..." 
                className="bg-transparent border-none outline-none text-xs font-black text-slate-900 w-full uppercase tracking-widest placeholder:text-slate-300"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <button className="hidden sm:flex items-center gap-2 px-6 py-4 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-xl shadow-slate-200">
              <Filter className="w-4 h-4" />
              Advanced
            </button>
          </div>

          {/* Desktop List */}
          <div className="hidden md:block bg-white rounded-[3rem] border border-slate-100 shadow-2xl shadow-slate-200/20 overflow-hidden">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50/30 border-b border-slate-50">
                  <th className="pl-10 pr-4 py-8 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">Personnel</th>
                  <th className="px-4 py-8 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">Exception Details</th>
                  <th className="px-4 py-8 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">Terminal Status</th>
                  <th className="pr-10 pl-4 py-8 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] text-right">Operational Links</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                <AnimatePresence mode="popLayout">
                  {filteredRequests.map((req) => (
                    <motion.tr 
                      layout
                      key={req.id} 
                      className="hover:bg-slate-50/20 transition-all group"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                    >
                      <td className="pl-10 pr-4 py-8">
                        <div className="flex items-center gap-5">
                          <div className="w-14 h-14 bg-slate-50 border border-slate-100 rounded-2xl flex items-center justify-center p-0.5 group-hover:scale-110 transition-transform">
                             <div className="w-full h-full rounded-[14px] bg-slate-900 text-white flex items-center justify-center font-black text-xs">
                              {req.employeeName?.[0]}
                             </div>
                          </div>
                          <div>
                            <p className="font-black text-slate-900 uppercase tracking-tight text-sm group-hover:text-indigo-600 transition-colors">{req.employeeName}</p>
                            <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest mt-0.5">ID: {req.employeeId.slice(-6)}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-8">
                        <div>
                          <p className="text-[11px] font-black text-slate-900 uppercase tracking-widest">{req.leaveType}</p>
                          <div className="flex items-center gap-2 mt-1.5 text-slate-400 font-bold text-xs">
                            <Calendar className="w-3 h-3" />
                            <span className="text-[10px] uppercase tracking-widest">{format(new Date(req.startDate), 'MMM dd')} - {format(new Date(req.endDate), 'MMM dd')}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-8">
                        {getStatusBadge(req.status)}
                      </td>
                      <td className="pr-10 pl-4 py-8">
                        {req.status === 'Pending' ? (
                          <div className="flex items-center justify-end gap-2">
                             <motion.button 
                              whileHover={{ scale: 1.05 }}
                              whileActive={{ scale: 0.95 }}
                              onClick={() => updateStatus(req.id, 'Approved')}
                              className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center border border-emerald-100 hover:bg-emerald-600 hover:text-white transition-all shadow-sm"
                            >
                              <CheckCircle2 className="w-5 h-5" />
                            </motion.button>
                            <motion.button 
                              whileHover={{ scale: 1.05 }}
                              whileActive={{ scale: 0.95 }}
                              onClick={() => updateStatus(req.id, 'Rejected')}
                              className="w-10 h-10 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center border border-rose-100 hover:bg-rose-600 hover:text-white transition-all shadow-sm"
                            >
                              <XCircle className="w-5 h-5" />
                            </motion.button>
                          </div>
                        ) : (
                          <div className="flex justify-end italic text-[10px] font-black text-slate-300 uppercase tracking-widest">
                            {req.status} @ {format(new Date(), 'HH:mm')}
                          </div>
                        )}
                      </td>
                    </motion.tr>
                  ))}
                </AnimatePresence>
                {filteredRequests.length === 0 && !loading && (
                  <tr>
                    <td colSpan={4} className="py-32 text-center text-slate-300 font-black uppercase tracking-[0.3em] text-[10px]">
                      <AlertCircle className="w-12 h-12 mx-auto mb-6 opacity-20" />
                      No exceptional data packets detected
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Mobile Cards */}
          <div className="md:hidden space-y-6">
            {filteredRequests.map((req) => (
              <div key={req.id} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-2xl shadow-slate-200/10 space-y-8">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-5">
                    <div className="w-14 h-14 bg-slate-900 rounded-2xl flex items-center justify-center font-black text-white shadow-lg shadow-slate-200">
                      {req.employeeName?.[0]}
                    </div>
                    <div>
                      <h4 className="font-black text-slate-900 uppercase tracking-tighter text-base">{req.employeeName}</h4>
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">{req.leaveType}</p>
                    </div>
                  </div>
                  {getStatusBadge(req.status)}
                </div>

                <div className="space-y-4 p-6 bg-slate-50 rounded-[2rem] border border-slate-100 shadow-inner">
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Range</span>
                    <span className="text-[10px] font-black text-slate-900 uppercase tracking-widest">{format(new Date(req.startDate), 'MMM dd')} - {format(new Date(req.endDate), 'MMM dd')}</span>
                  </div>
                  <div className="pt-4 border-t border-slate-200/50">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">Subjective Intent:</p>
                    <p className="text-xs font-medium text-slate-600 leading-relaxed italic">"{req.reason}"</p>
                  </div>
                </div>

                {req.status === 'Pending' && (
                  <div className="grid grid-cols-2 gap-3">
                    <motion.button 
                      whileActive={{ scale: 0.95 }}
                      onClick={() => updateStatus(req.id, 'Approved')}
                      className="p-4 bg-emerald-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-emerald-100 flex items-center justify-center gap-2"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      Approve
                    </motion.button>
                    <motion.button 
                      whileActive={{ scale: 0.95 }}
                      onClick={() => updateStatus(req.id, 'Rejected')}
                      className="p-4 bg-rose-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-rose-100 flex items-center justify-center gap-2"
                    >
                      <XCircle className="w-4 h-4" />
                      Reject
                    </motion.button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Sidebar Summary */}
        <div className="space-y-8">
           <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-2xl shadow-slate-200/30">
             <div className="flex items-center gap-4 mb-10 text-slate-900">
               <div className="w-12 h-12 bg-slate-900 text-indigo-400 rounded-2xl flex items-center justify-center shadow-lg">
                 <Filter className="w-6 h-6" />
               </div>
               <div>
                <h3 className="text-sm font-black tracking-tight uppercase">Registry Metrics</h3>
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Global Overview</p>
               </div>
             </div>

             <div className="space-y-6">
                <MetricRow label="Incoming" count={requests.filter(r => r.status === 'Pending').length} color="indigo" />
                <MetricRow label="Authorized" count={requests.filter(r => r.status === 'Approved').length} color="emerald" />
                <MetricRow label="Terminated" count={requests.filter(r => r.status === 'Rejected').length} color="rose" />
                
                <div className="pt-8 mt-8 border-t border-slate-50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Efficiency</span>
                    <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">74%</span>
                  </div>
                  <div className="h-2.5 bg-slate-50 border border-slate-100 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: '74%' }}
                      className="h-full bg-slate-900"
                    />
                  </div>
                </div>
             </div>
           </div>

           <div className="bg-stone-900 rounded-[3rem] p-10 text-white relative overflow-hidden shadow-2xl shadow-stone-950/40 group">
             <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform duration-[2000ms]">
               <AlertCircle className="w-32 h-32" />
             </div>
             <p className="text-[10px] font-black text-stone-500 uppercase tracking-[0.3em] mb-6">Protocol Alert</p>
             <h4 className="text-xl font-black leading-tight mb-4 tracking-tight uppercase underline decoration-indigo-500 underline-offset-8">Auto-Archive</h4>
             <p className="text-stone-400 text-xs font-medium leading-relaxed opacity-80">
               Processed requests are securely archived after 90 days. Approval timestamps are immutable and cryptographically hashed.
             </p>
             <motion.div 
              whileHover={{ x: 5 }}
              className="mt-12 flex items-center gap-3 text-white text-[10px] font-black uppercase tracking-widest cursor-pointer group hover:text-indigo-400 transition-colors"
             >
               Compliance Docs
               <ArrowRight className="w-4 h-4 text-stone-600 transition-colors group-hover:text-indigo-400" />
             </motion.div>
           </div>
        </div>
      </div>
    </div>
  );
}

const MetricRow = ({ label, count, color }: any) => {
  const colors: any = {
    indigo: 'bg-indigo-500',
    emerald: 'bg-emerald-500',
    rose: 'bg-rose-500'
  };
  return (
    <div className="flex items-center justify-between p-4 bg-slate-50 border border-slate-100 rounded-2xl hover:bg-white transition-colors cursor-default group">
      <div className="flex items-center gap-3">
        <div className={cn("w-2 h-2 rounded-full", colors[color])} />
        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest group-hover:text-slate-600 transition-colors">{label}</span>
      </div>
      <span className="text-sm font-black text-slate-900">{count}</span>
    </div>
  );
};
