import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot, addDoc, deleteDoc, doc, updateDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { useAuth } from '../../lib/AuthContext';
import { Employee } from '../../types';
import { Plus, Search, MoreVertical, Edit2, Trash2, UserPlus, Download, Mail, Phone, MapPin, Calendar, Clock, ArrowRight, Filter, X, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import * as XLSX from 'xlsx';

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ');
}

export default function EmployeeList() {
  const { profile } = useAuth();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);

  useEffect(() => {
    if (!profile?.organizationId) return;

    const q = query(collection(db, 'employees'), where('organizationId', '==', profile.organizationId));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setEmployees(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Employee)));
      setLoading(false);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'employees'));

    return () => unsubscribe();
  }, [profile]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile?.organizationId) return;

    const form = e.target as HTMLFormElement;
    const data = {
      name: (form.elements.namedItem('name') as HTMLInputElement).value,
      employeeId: (form.elements.namedItem('employeeId') as HTMLInputElement).value,
      designation: (form.elements.namedItem('designation') as HTMLInputElement).value,
      joiningDate: (form.elements.namedItem('joiningDate') as HTMLInputElement).value,
      organizationId: profile.organizationId
    };

    try {
      if (editingEmployee) {
        await updateDoc(doc(db, 'employees', editingEmployee.id), data);
      } else {
        await addDoc(collection(db, 'employees'), data);
      }
      setShowModal(false);
      setEditingEmployee(null);
    } catch (err) {
      handleFirestoreError(err, editingEmployee ? OperationType.UPDATE : OperationType.CREATE, 'employees');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to remove this employee?')) return;
    try {
      await deleteDoc(doc(db, 'employees', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `employees/${id}`);
    }
  };

  const exportToExcel = () => {
    const ws = XLSX.utils.json_to_sheet(employees);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Employees");
    XLSX.writeFile(wb, "Employee_List.xlsx");
  };

  const filteredEmployees = employees.filter(e => 
    e.name.toLowerCase().includes(search.toLowerCase()) || 
    e.employeeId.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-[1600px] mx-auto space-y-8 pb-20">
      {/* Page Header */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8 bg-white p-8 sm:p-10 rounded-[3rem] border border-slate-100 shadow-2xl shadow-slate-200/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-10 opacity-[0.02] pointer-events-none">
          <Users className="w-56 h-56 text-slate-900" />
        </div>
        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-3">
            <span className="h-0.5 w-8 bg-slate-200" />
            <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.3em]">Personnel Database</span>
          </div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tighter leading-none uppercase">Team Directory</h1>
          <p className="text-slate-400 font-bold text-sm max-w-md">Manage node assignments and terminal authorizations for your workforce.</p>
        </div>
        <div className="flex flex-wrap items-center gap-4 relative z-10">
          <motion.button 
            whileHover={{ y: -2 }}
            whileActive={{ scale: 0.95 }}
            onClick={exportToExcel}
            className="flex items-center gap-3 px-8 py-4 bg-slate-50 text-slate-900 rounded-2xl hover:bg-slate-100 transition-all font-black text-[10px] uppercase tracking-widest border border-slate-100 shadow-sm"
          >
            <Download className="w-4 h-4 text-indigo-600" />
            <span>Export Registry</span>
          </motion.button>
          <motion.button 
            whileHover={{ y: -2 }}
            whileActive={{ scale: 0.95 }}
            onClick={() => { setEditingEmployee(null); setShowModal(true); }}
            className="flex items-center gap-3 px-8 py-4 bg-slate-900 text-white rounded-2xl hover:bg-slate-800 transition-all font-black text-[10px] uppercase tracking-widest shadow-2xl shadow-slate-200"
          >
            <Plus className="w-4 h-4 text-indigo-400" />
            <span>Enroll Member</span>
          </motion.button>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-col sm:flex-row gap-4 bg-white p-6 rounded-[2rem] border border-slate-100 shadow-xl shadow-slate-200/10">
        <div className="relative flex-1 group">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
          <input 
            type="text"
            placeholder="Search system registry by name, identifier or role..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-14 pr-6 py-4.5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-8 focus:ring-slate-100/50 focus:border-slate-300 transition-all font-bold text-xs text-slate-900 placeholder:text-slate-300 uppercase tracking-widest"
          />
        </div>
        <button className="flex items-center justify-center gap-3 px-8 py-4.5 bg-white border border-slate-100 text-slate-400 hover:text-slate-900 rounded-2xl hover:bg-slate-50 transition-all font-black text-[10px] uppercase tracking-widest group shadow-sm active:scale-95">
          <Filter className="w-4 h-4 group-hover:rotate-180 transition-transform duration-500" />
          <span>Metric Filter</span>
        </button>
      </div>

      {/* Table Desktop / Cards Mobile */}
      <div className="space-y-6">
        {/* Desktop Table View */}
        <div className="hidden lg:block bg-white rounded-[3rem] border border-slate-100 shadow-2xl shadow-slate-200/20 overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/30">
                <th className="pl-10 pr-4 py-8 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-50">Authorized Personnel</th>
                <th className="px-4 py-8 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-50">System Identifier</th>
                <th className="px-4 py-8 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-50">Technical Role</th>
                <th className="px-4 py-8 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-50">Onboarding Data</th>
                <th className="px-4 py-8 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-50">Sync Status</th>
                <th className="pl-4 pr-10 py-8 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-50 text-right">Ops</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredEmployees.map((emp) => (
                <tr key={emp.id} className="hover:bg-slate-50/20 transition-all group cursor-default">
                  <td className="pl-10 pr-4 py-6">
                    <div className="flex items-center gap-5">
                      <div className="w-14 h-14 rounded-2xl bg-slate-50 border border-slate-100 p-0.5 group-hover:scale-105 transition-transform">
                        <div className="w-full h-full rounded-[14px] bg-slate-900 text-white flex items-center justify-center font-black text-xs shadow-md">
                          {emp.name?.[0]}
                        </div>
                      </div>
                      <div className="min-w-0">
                        <p className="font-black text-slate-900 uppercase tracking-tighter text-sm group-hover:text-indigo-600 transition-colors">{emp.name}</p>
                        <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest mt-0.5">Verification Confirmed</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-6">
                    <span className="inline-flex items-center px-4 py-2 bg-white border border-slate-200 text-slate-400 rounded-[10px] text-[10px] font-black shadow-sm uppercase tracking-widest">{emp.employeeId}</span>
                  </td>
                  <td className="px-4 py-6">
                    <p className="text-xs font-black text-slate-600 uppercase tracking-tight">{emp.designation}</p>
                    <p className="text-[9px] font-bold text-slate-400 mt-1 uppercase tracking-widest">Level 1 Authorized</p>
                  </td>
                  <td className="px-4 py-6">
                    <div className="flex items-center gap-3 text-slate-400 font-bold text-[10px] uppercase tracking-widest">
                      <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                      {format(new Date(emp.joiningDate), 'MMM dd, yyyy')}
                    </div>
                  </td>
                  <td className="px-4 py-6">
                    <div className="flex items-center gap-2">
                       <div className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                      </div>
                      <span className="text-[10px] font-black text-slate-900 uppercase tracking-widest">Linked</span>
                    </div>
                  </td>
                  <td className="pl-4 pr-10 py-6 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0">
                       <button 
                         onClick={() => { setEditingEmployee(emp); setShowModal(true); }}
                         className="p-3 text-slate-400 hover:text-indigo-600 hover:bg-white rounded-xl border border-transparent hover:border-indigo-100 hover:shadow-lg hover:shadow-indigo-100/40 transition-all active:scale-90"
                         title="Edit Profile"
                        >
                         <Edit2 className="w-4 h-4" />
                       </button>
                       <button 
                         onClick={() => handleDelete(emp.id)}
                         className="p-3 text-slate-400 hover:text-rose-600 hover:bg-white rounded-xl border border-transparent hover:border-rose-100 hover:shadow-lg hover:shadow-rose-100/40 transition-all active:scale-90"
                         title="Remove Member"
                        >
                         <Trash2 className="w-4 h-4" />
                       </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile Grid View */}
        <div className="lg:hidden grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filteredEmployees.map((emp) => (
            <div key={emp.id} className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-xl shadow-slate-200/10 space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-black text-sm">
                    {emp.name?.[0]}
                  </div>
                  <div>
                    <h4 className="font-black text-slate-900 tracking-tight">{emp.name}</h4>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{emp.employeeId}</p>
                  </div>
                </div>
                <div className="flex gap-1">
                   <button 
                     onClick={() => { setEditingEmployee(emp); setShowModal(true); }}
                     className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-slate-50 rounded-lg"
                   >
                     <Edit2 className="w-4 h-4" />
                   </button>
                   <button 
                     onClick={() => handleDelete(emp.id)}
                     className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg"
                   >
                     <Trash2 className="w-4 h-4" />
                   </button>
                </div>
              </div>
              
              <div className="pt-6 border-t border-slate-50 space-y-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-400 uppercase tracking-tighter">Designation</span>
                  <span className="font-black text-slate-900">{emp.designation}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-400 uppercase tracking-tighter">Joined</span>
                  <span className="font-black text-slate-900">{emp.joiningDate}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-400 uppercase tracking-tighter">Status</span>
                  <span className="px-2 py-1 bg-emerald-50 text-emerald-600 rounded-lg font-black uppercase tracking-tighter">Active</span>
                </div>
              </div>
              
              <button className="w-full py-4 bg-slate-50 text-slate-900 font-black rounded-2xl text-xs uppercase tracking-widest flex items-center justify-center gap-2">
                View Full Profile
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

        {filteredEmployees.length === 0 && !loading && (
          <div className="py-20 text-center bg-white rounded-[2.5rem] border border-slate-100 shadow-sm">
            <div className="w-20 h-20 bg-slate-50 rounded-3xl flex items-center justify-center mx-auto mb-6">
              <UserPlus className="w-10 h-10 text-slate-300" />
            </div>
            <h3 className="text-xl font-black text-slate-900 tracking-tight">No team members found</h3>
            <p className="text-slate-400 font-medium max-w-[240px] mx-auto mt-2">Try adjusting your filters or add a new member to the organization.</p>
            <button 
              onClick={() => { setEditingEmployee(null); setShowModal(true); }}
              className="mt-8 px-8 py-3.5 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-indigo-100 hover:scale-105 active:scale-95 transition-all"
            >
              Add Your First Member
            </button>
          </div>
        )}
      </div>

      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4 z-[60]">
            <motion.div 
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.95 }}
              className="bg-white rounded-[2.5rem] p-10 max-w-lg w-full shadow-2xl relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-10 opacity-5 -mr-10 -mt-10">
                <UserPlus className="w-40 h-40 text-slate-900" />
              </div>

              <div className="relative z-10">
                <div className="flex items-center justify-between mb-10">
                  <div>
                    <h3 className="text-3xl font-black text-slate-900 tracking-tight">{editingEmployee ? 'Edit Member' : 'New Member'}</h3>
                    <p className="text-sm font-medium text-slate-400 mt-1">Populate the fields below to {editingEmployee ? 'update' : 'enroll'} staff.</p>
                  </div>
                  <button onClick={() => setShowModal(false)} className="p-3 text-slate-400 hover:bg-slate-50 rounded-2xl transition-all">
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="sm:col-span-2">
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.1em] mb-2 px-1">Full Name</label>
                      <input 
                        name="name" 
                        required 
                        placeholder="e.g. Alexander Hamilton"
                        defaultValue={editingEmployee?.name}
                        className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all font-bold text-slate-900 placeholder:text-slate-300"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.1em] mb-2 px-1">Employee ID</label>
                      <input 
                        name="employeeId" 
                        required 
                        placeholder="EMP-001"
                        defaultValue={editingEmployee?.employeeId}
                        className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all font-bold text-slate-900 placeholder:text-slate-300"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.1em] mb-2 px-1">Joining Date</label>
                      <div className="relative">
                        <input 
                          type="date" 
                          name="joiningDate" 
                          required 
                          defaultValue={editingEmployee?.joiningDate}
                          className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all font-bold text-slate-900"
                        />
                      </div>
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.1em] mb-2 px-1">Current Designation</label>
                      <input 
                        name="designation" 
                        required 
                        placeholder="e.g. Senior Software Engineer"
                        defaultValue={editingEmployee?.designation}
                        className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all font-bold text-slate-900 placeholder:text-slate-300"
                      />
                    </div>
                  </div>

                  <div className="flex gap-4 pt-6">
                    <button 
                      type="button" 
                      onClick={() => setShowModal(false)}
                      className="flex-1 py-4.5 bg-slate-100 text-slate-600 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 transition-all"
                    >
                      Dismiss
                    </button>
                    <button 
                      type="submit"
                      className="flex-[2] py-4.5 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-indigo-700 shadow-xl shadow-indigo-100/50 hover:scale-[1.02] active:scale-95 transition-all"
                    >
                      {editingEmployee ? 'Update Profile' : 'Enroll Member'}
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

