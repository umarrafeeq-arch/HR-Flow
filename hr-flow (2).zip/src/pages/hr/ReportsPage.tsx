import React, { useEffect, useState } from 'react';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { useAuth } from '../../lib/AuthContext';
import { Employee } from '../../types';
import { FileText, Download, Calendar, Filter, User, BarChart3, PieChart, TrendingUp, Sparkles, AlertCircle, FileSpreadsheet, Layers } from 'lucide-react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isWeekend } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import * as XLSX from 'xlsx';

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ');
}

export default function ReportsPage() {
  const { profile } = useAuth();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [month, setMonth] = useState(new Date());
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!profile?.organizationId) return;
    const qEmp = query(collection(db, 'employees'), where('organizationId', '==', profile.organizationId));
    getDocs(qEmp).then(snapshot => {
      setEmployees(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Employee)));
    });
  }, [profile]);

  const generateMonthlyReport = async () => {
    if (!profile?.organizationId) return;
    setLoading(true);
    try {
      const start = format(startOfMonth(month), 'yyyy-MM-dd');
      const end = format(endOfMonth(month), 'yyyy-MM-dd');
      
      const qAtt = query(
        collection(db, 'attendance'),
        where('organizationId', '==', profile.organizationId),
        where('date', '>=', start),
        where('date', '<=', end)
      );

      const snapshot = await getDocs(qAtt);
      const attendance = snapshot.docs.map(d => d.data());

      // Format for Excel
      const allDays = eachDayOfInterval({ start: startOfMonth(month), end: endOfMonth(month) });
      const reportData = employees.map(emp => {
        const empAtt = attendance.filter(a => a.employeeId === emp.id);
        const row: any = { 'Employee Name': emp.name, 'Employee ID': emp.employeeId };
        
        let present = 0;
        let absent = 0;
        let leaves = 0;

        allDays.forEach(day => {
          const dateStr = format(day, 'yyyy-MM-dd');
          const rec = empAtt.find(a => a.date === dateStr);
          const status = rec?.status || (isWeekend(day) ? 'Week Off' : '—');
          row[format(day, 'dd')] = status;
          if (status === 'Present') present++;
          else if (status === 'Absent') absent++;
          else if (status === 'Leave') leaves++;
        });

        row['Total Present'] = present;
        row['Total Absent'] = absent;
        row['Total Leaves'] = leaves;
        return row;
      });

      const ws = XLSX.utils.json_to_sheet(reportData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Monthly Report");
      XLSX.writeFile(wb, `Attendance_Report_${format(month, 'MMM_yyyy')}.xlsx`);
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'attendance');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-[1600px] mx-auto space-y-10 pb-20">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white p-8 sm:p-10 rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/20">
        <div className="space-y-1">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest">Analytics Beta</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">Intelligence & Reports</h1>
          <p className="text-slate-500 font-medium max-w-xl">Harness data-driven insights to optimize your workforce productivity and attendance patterns.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-2 p-3 bg-slate-50 border border-slate-100 rounded-2xl">
             <Layers className="w-5 h-5 text-indigo-600" />
             <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{employees.length} Active Records</span>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Main Report Card */}
        <motion.div 
          className="lg:col-span-2 group"
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <div className="h-full bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/20 relative overflow-hidden flex flex-col">
            <div className="absolute top-0 right-0 p-10 opacity-[0.03] -mr-10 -mt-10 group-hover:scale-110 group-hover:rotate-6 transition-transform duration-700">
              <FileSpreadsheet className="w-64 h-64 text-slate-900" />
            </div>

            <div className="relative z-10 flex-1">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center shadow-sm">
                  <FileText className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-slate-900 tracking-tight">Monthly Attendance Grid</h3>
                  <p className="text-slate-400 font-medium">Export a full lifecycle spread of your team's presence.</p>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-8 items-end pt-4">
                <div className="space-y-4">
                  <label className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">
                    <Calendar className="w-3 h-3" />
                    Target Report Month
                  </label>
                  <input 
                    type="month"
                    value={format(month, 'yyyy-MM')}
                    onChange={(e) => setMonth(new Date(e.target.value))}
                    className="w-full px-6 py-5 bg-slate-50 border border-slate-100 rounded-3xl outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 font-black text-slate-900 text-lg transition-all"
                  />
                </div>
                
                <div className="space-y-4">
                  <button 
                    onClick={generateMonthlyReport}
                    disabled={loading}
                    className="w-full h-[68px] bg-indigo-600 text-white rounded-3xl font-black text-xs uppercase tracking-widest hover:bg-indigo-700 transition-all flex items-center justify-center gap-3 shadow-2xl shadow-indigo-200 disabled:opacity-50 hover:scale-[1.02] active:scale-95"
                  >
                    <Download className={cn("w-5 h-5", loading ? "animate-bounce" : "")} />
                    {loading ? 'Processing Data...' : 'Generate Spreadsheet'}
                  </button>
                </div>
              </div>

              <div className="mt-12 p-6 bg-slate-50 rounded-3xl border border-slate-100 grid grid-cols-2 sm:grid-cols-3 gap-6">
                 <div>
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">File Format</p>
                   <p className="text-sm font-black text-slate-900 mt-1">Excel (.xlsx)</p>
                 </div>
                 <div>
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Data Points</p>
                   <p className="text-sm font-black text-slate-900 mt-1">31 Days + Totals</p>
                 </div>
                 <div className="hidden sm:block">
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Security</p>
                   <p className="text-sm font-black text-indigo-600 mt-1 uppercase tracking-tighter flex items-center gap-1">
                     <Sparkles className="w-3 h-3" /> Encrypted
                   </p>
                 </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Side Panels */}
        <div className="space-y-8 flex flex-col">
          <div className="bg-stone-900 p-8 sm:p-10 rounded-[2.5rem] text-white flex-1 relative overflow-hidden shadow-2xl shadow-stone-900/40">
             <div className="absolute bottom-0 right-0 p-8 opacity-5">
               <TrendingUp className="w-32 h-32" />
             </div>
             <div className="relative z-10">
               <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center mb-6 border border-white/5">
                 <BarChart3 className="w-6 h-6 text-indigo-400" />
               </div>
               <h3 className="text-xl font-black tracking-tight mb-2 uppercase tracking-tighter">Insights Hub</h3>
               <p className="text-stone-400 font-medium text-sm leading-relaxed mb-8">Detailed visual breakdowns of leave distribution and performance trends are coming to your dashboard soon.</p>
               
               <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/5 opacity-50 grayscale">
                    <span className="text-[10px] font-black uppercase tracking-widest opacity-60">Leave Distribution</span>
                    <PieChart className="w-4 h-4" />
                  </div>
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/5 opacity-50 grayscale">
                    <span className="text-[10px] font-black uppercase tracking-widest opacity-60">Performance Index</span>
                    <TrendingUp className="w-4 h-4" />
                  </div>
               </div>
               
               <div className="mt-8 flex items-center gap-2 px-4 py-2 bg-indigo-600/20 text-indigo-400 rounded-full border border-indigo-400/20 w-fit">
                 <Sparkles className="w-3 h-3" />
                 <span className="text-[8px] font-black uppercase tracking-[0.2em]">Developing Feature</span>
               </div>
             </div>
          </div>

          <div className="bg-amber-50 p-8 rounded-[2.5rem] border border-amber-100 flex items-start gap-4">
             <div className="w-10 h-10 bg-amber-500 text-white rounded-xl flex-shrink-0 flex items-center justify-center shadow-lg shadow-amber-200">
               <AlertCircle className="w-6 h-6" />
             </div>
             <div>
               <h4 className="font-black text-amber-900 text-sm uppercase tracking-tighter">Need custom reports?</h4>
               <p className="text-xs font-bold text-amber-700/60 mt-1 leading-relaxed">Our data architects can help you build custom SQL-based export templates for your specific payroll needs.</p>
               <button className="mt-4 text-[10px] font-black text-amber-600 uppercase tracking-widest border-b border-amber-200 hover:text-amber-700">Contact Infrastructure</button>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}

