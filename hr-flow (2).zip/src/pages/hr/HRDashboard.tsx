import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot, getDocs } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { useAuth } from '../../lib/AuthContext';
import { Users, CalendarCheck, Clock, FileText, TrendingUp, UserPlus, ArrowUpRight, ArrowDownRight, Calendar, LayoutDashboard } from 'lucide-react';
import { format } from 'date-fns';
import { motion } from 'motion/react';

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ');
}

export default function HRDashboard() {
  const { profile } = useAuth();
  const [stats, setStats] = useState({
    totalEmployees: 0,
    presentToday: 0,
    absentToday: 0,
    onLeave: 0
  });

  useEffect(() => {
    if (!profile?.organizationId) return;

    const orgId = profile.organizationId;
    
    // 1. Total Employees
    const qEmp = query(collection(db, 'employees'), where('organizationId', '==', orgId));
    const unsubscribeEmp = onSnapshot(qEmp, (snapshot) => {
      const total = snapshot.size;
      setStats(prev => ({ ...prev, totalEmployees: total }));
    });

    return () => {
      unsubscribeEmp();
    };
  }, [profile]);

  return (
    <div className="max-w-[1600px] mx-auto space-y-10 pb-20">
      {/* Welcome Header */}
      <div className="flex flex-col xl:flex-row xl:items-end justify-between gap-8">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <span className="h-0.5 w-8 bg-slate-200" />
            <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.3em]">Operational Pulse</span>
          </div>
          <h1 className="text-4xl xs:text-5xl font-black text-slate-900 tracking-tighter leading-none">
            Hello, {profile?.name?.split(' ')?.[0] || 'Team'} <span className="animate-wave origin-bottom-right">👋</span>
          </h1>
          <p className="text-slate-500 font-medium max-w-xl text-sm xs:text-base leading-relaxed">
            Monitor terminal health and team logistics at <span className="text-slate-900 font-black decoration-indigo-200 decoration-wavy underline underline-offset-4">HQ</span>.
          </p>
        </div>
        
        <div className="flex items-center gap-3 bg-white p-2.5 rounded-[1.75rem] border border-slate-100 shadow-xl shadow-slate-200/20 self-start xl:self-center">
          <div className="flex items-center gap-3 px-5 py-3 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-slate-200">
            <Calendar className="w-4 h-4 text-indigo-400" />
            {format(new Date(), 'MMM dd, yyyy')}
          </div>
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileActive={{ scale: 0.95 }}
            className="p-3 bg-white text-slate-400 hover:text-indigo-600 rounded-2xl border border-slate-100 transition-all hover:bg-indigo-50"
          >
            <TrendingUp className="w-5 h-5" />
          </motion.button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
        <StatCard 
          label="Total Strength" 
          value={stats.totalEmployees} 
          icon={Users} 
          trend="+4%"
          trendUp={true}
          color="indigo"
          description="Total active employees"
        />
        <StatCard 
          label="Present Today" 
          value={12} 
          icon={CalendarCheck} 
          trend="85%"
          trendUp={true}
          color="emerald"
          description="On-site & Remote"
        />
        <StatCard 
          label="Avg. In-Time" 
          value="09:12 AM" 
          icon={Clock} 
          trend="-2m"
          trendUp={false}
          color="amber"
          description="Since last week"
        />
        <StatCard 
          label="On-Leave Today" 
          value={3} 
          icon={FileText} 
          trend="+1"
          trendUp={false}
          color="rose"
          description="Approved absence"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 items-start">
        {/* Main Chart Section */}
        <div className="lg:col-span-2 space-y-10">
          <div className="bg-white rounded-[3rem] p-8 sm:p-10 border border-slate-100 shadow-2xl shadow-slate-200/30 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-10 opacity-[0.02] pointer-events-none">
              <TrendingUp className="w-64 h-64 text-indigo-600" />
            </div>
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 mb-12 relative z-10">
              <div>
                <h2 className="text-2xl font-black text-slate-900 tracking-tighter uppercase">Terminal Metrics</h2>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Real-time attendance velocity</p>
              </div>
              <div className="flex items-center gap-2 p-1.5 bg-slate-50 rounded-2xl border border-slate-100">
                <button className="px-5 py-2.5 bg-white text-slate-900 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-sm border border-slate-100 transition-all">L7 Days</button>
                <button className="px-5 py-2.5 text-slate-400 hover:text-slate-600 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all">L30 Days</button>
              </div>
            </div>
            
            <div className="h-[320px] flex items-end justify-between gap-2 sm:gap-4 px-2 relative z-10">
              {[82, 88, 76, 94, 85, 91, 98].map((val, i) => (
                <div key={i} className="flex-1 group relative flex flex-col items-center h-full justify-end">
                  <div className="absolute top-0 opacity-0 group-hover:opacity-100 transition-all duration-300 transform -translate-y-4">
                    <div className="bg-slate-900 text-white text-[9px] font-black px-2 py-1 rounded-lg shadow-xl uppercase">
                      {val}% Load
                    </div>
                  </div>
                  <motion.div 
                     initial={{ height: 0 }}
                     animate={{ height: `${val}%` }}
                     transition={{ duration: 1.2, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
                     className="w-full max-w-[48px] rounded-t-2xl bg-gradient-to-t from-slate-900 to-slate-800 transition-all duration-300 cursor-pointer shadow-lg group-hover:to-indigo-500"
                   />
                   <span className="text-[9px] font-black text-slate-300 mt-5 uppercase tracking-widest leading-none">
                    {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i]}
                   </span>
                </div>
              ))}
            </div>
          </div>

          {/* Secondary Bento Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
            <div className="p-10 bg-slate-900 rounded-[2.5rem] text-white overflow-hidden relative group border border-slate-800 shadow-2xl">
              <div className="absolute -top-12 -right-12 p-12 opacity-10 group-hover:scale-110 transition-transform duration-1000 group-hover:rotate-12">
                <LayoutDashboard className="w-48 h-48 text-indigo-400" />
              </div>
              <div className="relative z-10">
                <div className="flex items-center gap-2 mb-8">
                  <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                  <p className="text-indigo-400 text-[10px] font-black uppercase tracking-[0.25em]">Live Event</p>
                </div>
                <h3 className="text-3xl font-black mb-4 tracking-tighter leading-none uppercase">Team<br />Syncronization</h3>
                <p className="text-slate-400 text-xs mb-10 leading-relaxed font-medium">Standard protocol review for remote terminal operations starting in 4h.</p>
                <button className="px-8 py-4 bg-indigo-600 text-white font-black rounded-2xl text-[10px] uppercase tracking-widest hover:bg-indigo-500 transition-all active:scale-95 shadow-xl shadow-indigo-900/40">Secure Seat</button>
              </div>
            </div>
            
            <div className="p-10 bg-white rounded-[2.5rem] text-slate-900 overflow-hidden relative group border border-slate-100 shadow-2xl shadow-slate-200/20">
              <div className="absolute -bottom-16 -right-16 p-16 opacity-[0.03] group-hover:-translate-y-8 transition-transform duration-1000 group-hover:-rotate-12">
                <Users className="w-64 h-64 text-indigo-600" />
              </div>
              <div className="relative z-10">
                <p className="text-indigo-600 text-[10px] font-black uppercase tracking-[0.25em] mb-8">Personnel</p>
                <h3 className="text-3xl font-black mb-4 tracking-tighter leading-none uppercase">Hiring<br />Pipeline</h3>
                <p className="text-slate-400 text-xs mb-10 leading-relaxed font-medium">Internal growth metrics show a 12% increase in developer node requests.</p>
                <div className="flex -space-x-3 mb-8">
                  {[1,2,3].map(i => (
                    <div key={i} className="w-10 h-10 rounded-xl bg-slate-100 border-2 border-white flex items-center justify-center font-black text-[10px] text-slate-400">
                      {['JS', 'RM', 'TH'][i-1]}
                    </div>
                  ))}
                  <div className="w-10 h-10 rounded-xl bg-indigo-50 border-2 border-white flex items-center justify-center font-black text-[10px] text-indigo-600">
                    +4
                  </div>
                </div>
                <button className="px-8 py-4 bg-slate-50 text-slate-900 font-black rounded-2xl text-[10px] uppercase tracking-widest hover:bg-slate-100 transition-all border border-slate-100">Audit Flow</button>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar Widgets */}
        <div className="space-y-10 lg:sticky lg:top-[120px]">
           <div className="bg-white rounded-[3rem] p-10 border border-slate-100 shadow-2xl shadow-slate-200/30">
             <div className="flex items-center justify-between mb-10">
               <div>
                  <h3 className="font-black text-slate-900 tracking-tighter uppercase text-sm">Deployment Exceptions</h3>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Active Leave Cycles</p>
               </div>
               <span className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center font-black text-xs border border-rose-100">03</span>
             </div>
             
             <div className="space-y-8">
                {[
                  { name: 'James Wilson', type: 'Clinical Recovery', code: 'MED', status: 'Active', color: 'rose' },
                  { name: 'Sarah Miller', type: 'Personnel Break', code: 'PRL', status: 'Pending', color: 'indigo' },
                  { name: 'Tom Hardy', type: 'Remote Node', code: 'WFH', status: 'Active', color: 'amber' },
                ].map((emp, i) => (
                  <div key={i} className="flex items-center gap-5 group cursor-pointer">
                    <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center font-black text-[10px] transition-all group-hover:scale-110 shadow-sm border", 
                      emp.color === 'rose' ? 'bg-rose-50 text-rose-600 border-rose-100' : 
                      emp.color === 'indigo' ? 'bg-indigo-50 text-indigo-600 border-indigo-100' : 'bg-amber-50 text-amber-600 border-amber-100'
                    )}>
                      {emp.code}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-black text-slate-900 truncate uppercase tracking-tight">{emp.name}</p>
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-[0.1em] mt-0.5">{emp.type}</p>
                    </div>
                    <div className={cn("w-2 h-2 rounded-full", i === 1 ? 'bg-amber-400 animate-pulse' : 'bg-emerald-400')} />
                  </div>
                ))}
             </div>
             
             <button className="w-full mt-10 py-5 bg-slate-900 text-white rounded-3xl text-[10px] font-black hover:bg-slate-800 transition-all uppercase tracking-[0.2em] shadow-xl shadow-slate-200">
               Access Log Manager
             </button>
           </div>

           <div className="bg-indigo-600 rounded-[3rem] p-10 text-white relative overflow-hidden group shadow-2xl shadow-indigo-200/50">
             <div className="absolute -right-12 -bottom-12 opacity-10 group-hover:rotate-12 transition-transform duration-1000">
               <UserPlus className="w-56 h-56" />
             </div>
             <div className="relative z-10">
              <div className="w-14 h-14 bg-indigo-500 rounded-2xl flex items-center justify-center mb-8 shadow-lg">
                <UserPlus className="w-7 h-7 text-white" />
              </div>
              <p className="text-indigo-200 text-[10px] font-black uppercase tracking-[0.3em] mb-4">Infrastructure</p>
              <h3 className="text-3xl font-black mb-6 tracking-tighter leading-none uppercase">Provision<br />Nodes</h3>
              <p className="text-indigo-100 text-sm mb-12 leading-relaxed font-medium">Standard onboarding protocols for new enterprise personnel.</p>
              <motion.button 
                whileHover={{ y: -5 }}
                whileActive={{ scale: 0.95 }}
                className="flex items-center justify-between w-full p-6 bg-white text-indigo-900 font-black rounded-3xl text-[11px] uppercase tracking-widest shadow-2xl shadow-indigo-950/20"
              >
                Start Sequence
                <ArrowUpRight className="w-5 h-5" />
              </motion.button>
             </div>
           </div>
        </div>
      </div>
    </div>
  );
}

const StatCard = ({ label, value, icon: Icon, trend, trendUp, color, description }: any) => {
  const colorMap: any = {
    indigo: { accent: 'bg-indigo-500', bg: 'bg-indigo-50/30' },
    emerald: { accent: 'bg-emerald-500', bg: 'bg-emerald-50/30' },
    amber: { accent: 'bg-amber-500', bg: 'bg-amber-50/30' },
    rose: { accent: 'bg-rose-500', bg: 'bg-rose-50/30' },
  };

  const scheme = colorMap[color] || colorMap.indigo;

  return (
    <div className="group bg-white p-6 sm:p-8 rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/20 transition-all hover:shadow-2xl hover:shadow-slate-200/40 relative overflow-hidden">
      <div className={cn("absolute top-0 right-0 w-32 h-32 opacity-[0.03] -mr-8 -mt-8 rounded-full", scheme.accent)} />
      
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-8">
          <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg", scheme.accent)}>
            <Icon className="w-6 h-6" />
          </div>
          <div className="flex flex-col items-end">
            <div className={cn(
              "flex items-center gap-1 px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-tighter",
              trendUp ? "bg-emerald-500 text-white" : "bg-slate-900 text-white"
            )}>
              {trendUp ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
              {trend}
            </div>
          </div>
        </div>

        <div className="space-y-1">
          <h4 className="text-3xl font-black text-slate-900 tracking-tighter leading-none">{value}</h4>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{label}</p>
        </div>
        
        <div className="mt-6 pt-6 border-t border-slate-50 flex items-center justify-between">
          <span className="text-[10px] font-bold text-slate-400 italic">{description}</span>
          <div className="flex gap-0.5">
            {[1,2,3,4].map(i => <div key={i} className={cn("w-1 h-3 rounded-full", i < 4 ? scheme.accent : 'bg-slate-100')} />)}
          </div>
        </div>
      </div>
    </div>
  );
};

