import React, { useState } from 'react';
import { useAuth } from '../../lib/AuthContext';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { Building, Shield, Bell, Save, User, Globe, Lock, Palette, Smartphone, Mail, Building2, Trash2, PlusCircle, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ');
}

export default function Settings() {
  const { profile, user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'general' | 'security' | 'billing'>('general');

  const tabs = [
    { id: 'general', label: 'General', icon: Building2 },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'billing', label: 'Billing', icon: Globe },
  ] as const;

  if (!profile) return null;

  return (
    <div className="max-w-[1400px] mx-auto space-y-12 pb-20">
      {/* Header */}
      <div className="space-y-2">
        <div className="flex items-center gap-3">
          <span className="h-0.5 w-8 bg-slate-200" />
          <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.3em]">Workspace Orchestration</span>
        </div>
        <h1 className="text-4xl font-black text-slate-900 tracking-tighter leading-none uppercase">Settings</h1>
        <p className="text-slate-400 font-bold text-sm max-w-md">Configure core terminal protocols and organizational data parameters.</p>
      </div>

      <div className="grid lg:grid-cols-[1fr,320px] gap-12 items-start">
        <div className="space-y-10">
          {/* Tabs Navigation */}
          <div className="flex items-center gap-2 p-1.5 bg-slate-100 rounded-2xl w-fit">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "flex items-center gap-2.5 px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all",
                  activeTab === tab.id 
                    ? "bg-white text-slate-900 shadow-xl shadow-slate-200" 
                    : "text-slate-400 hover:text-slate-600"
                )}
              >
                <tab.icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            ))}
          </div>

          {/* Main Configuration Form */}
          <div className="space-y-8">
            {activeTab === 'general' && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }} 
                animate={{ opacity: 1, y: 0 }}
                className="space-y-8"
              >
                {/* Section: Branding */}
                <div className="bg-white rounded-[3rem] border border-slate-100 shadow-2xl shadow-slate-200/20 overflow-hidden">
                  <div className="p-10 border-b border-slate-50 bg-slate-50/30 flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                        <Palette className="w-5 h-5 text-indigo-500" />
                        Identity & Branding
                      </h3>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Personnel Facing Visuals</p>
                    </div>
                  </div>
                  
                  <div className="p-10 space-y-10">
                    <div className="flex flex-col sm:flex-row items-center gap-10">
                      <div className="relative group">
                        <div className="w-32 h-32 rounded-[2.5rem] bg-slate-900 text-white flex items-center justify-center font-black text-4xl shadow-2xl shadow-slate-200 transform transition-transform group-hover:rotate-3">
                          {profile.companyName?.[0]}
                        </div>
                        <button className="absolute -bottom-2 -right-2 p-3 bg-white text-slate-900 rounded-2xl shadow-xl border border-slate-100 hover:scale-110 active:scale-95 transition-all">
                          <PlusCircle className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="text-center sm:text-left space-y-4">
                        <h4 className="font-black text-slate-900 uppercase tracking-tighter text-sm">Organizational Glyph</h4>
                        <p className="text-[11px] text-slate-400 font-bold leading-relaxed max-w-[240px] uppercase tracking-wide">Standard identifier for internal communication and headers.</p>
                        <div className="flex items-center justify-center sm:justify-start gap-3 pt-2">
                          <button className="px-5 py-3 bg-slate-900 text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-800 transition-colors shadow-lg">Upload Glyph</button>
                          <button className="px-5 py-3 bg-white text-slate-400 rounded-xl font-black text-[10px] uppercase tracking-widest border border-slate-100 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-100 transition-all">Reset</button>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6 border-t border-slate-50">
                      <div className="space-y-3">
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Legal Entity Name</label>
                        <input 
                          defaultValue={profile.companyName}
                          className="w-full px-6 py-4.5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-8 focus:ring-indigo-50/50 focus:border-indigo-100 font-bold text-slate-900 uppercase tracking-widest text-xs transition-all" 
                        />
                      </div>
                      <div className="space-y-3">
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Assigned Admin</label>
                        <div className="relative">
                          <User className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                          <input 
                            defaultValue={profile.hrName}
                            className="w-full pl-12 pr-6 py-4.5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-8 focus:ring-indigo-50/50 focus:border-indigo-100 font-bold text-slate-900 uppercase tracking-widest text-xs transition-all" 
                          />
                        </div>
                      </div>
                      <div className="space-y-3 md:col-span-2">
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Network Endpoint (Email)</label>
                        <div className="relative">
                          <Mail className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                          <input 
                            disabled
                            value={profile.hrEmail}
                            className="w-full pl-12 pr-6 py-4.5 bg-slate-100 border border-transparent rounded-2xl font-bold text-slate-400 cursor-not-allowed uppercase tracking-widest text-xs" 
                          />
                        </div>
                      </div>
                    </div>

                    <button className="flex items-center justify-center gap-3 px-10 py-5 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-2xl shadow-slate-200 transition-all hover:scale-105 active:scale-95 group">
                      <Save className="w-4 h-4 text-indigo-400 transition-transform group-hover:scale-110" />
                      Commit Changes
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'security' && (
              <motion.div 
                 initial={{ opacity: 0, y: 10 }} 
                 animate={{ opacity: 1, y: 0 }}
                 className="space-y-8"
              >
                <div className="bg-white rounded-[3rem] border border-slate-100 shadow-2xl shadow-slate-200/20 overflow-hidden">
                  <div className="p-10 border-b border-slate-50 bg-slate-50/30">
                    <h3 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                      <Shield className="w-5 h-5 text-indigo-500" />
                      Security Protocols
                    </h3>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Access control & Encryptions</p>
                  </div>
                  <div className="p-10 space-y-10">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 p-8 bg-slate-900 rounded-[2.5rem] text-white">
                      <div className="flex items-center gap-5">
                        <div className="w-14 h-14 bg-indigo-500 rounded-2xl flex items-center justify-center shadow-lg">
                          <Smartphone className="w-7 h-7 text-white" />
                        </div>
                        <div>
                          <h4 className="font-black uppercase tracking-tight text-base">Multi-Factor Gateway</h4>
                          <p className="text-[10px] text-indigo-200 font-bold uppercase tracking-widest mt-0.5">Biometric or Token Required</p>
                        </div>
                      </div>
                      <button className="px-6 py-4 bg-white text-slate-900 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-slate-950/20 active:scale-95 transition-all">Configure 2FA</button>
                    </div>

                    <div className="space-y-6">
                      <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-1 pb-4 border-b border-slate-50">Operational Restrictions</h4>
                      <div className="space-y-4">
                        <ToggleSetting 
                          title="IP Whitelisting"
                          description="Restrict terminal access to designated enterprise IPv4/v6 nodes."
                          active={false}
                        />
                        <ToggleSetting 
                          title="Auto-Termination"
                          description="Force logout sequence after 45 minutes of console inactivity."
                          active={true}
                        />
                        <ToggleSetting 
                          title="Activity Mirror"
                          description="Log all administrative operations to the global audit stream."
                          active={true}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'billing' && (
              <motion.div 
                 initial={{ opacity: 0, y: 10 }} 
                 animate={{ opacity: 1, y: 0 }}
                 className="bg-slate-900 rounded-[3rem] p-16 text-white relative overflow-hidden shadow-2xl shadow-indigo-100"
              >
                 <div className="absolute top-0 right-0 p-12 opacity-10 pointer-events-none">
                   <Globe className="w-72 h-72" />
                 </div>
                 <div className="relative z-10 max-w-sm space-y-8">
                   <div className="w-16 h-16 bg-white/10 backdrop-blur-xl rounded-2xl flex items-center justify-center border border-white/10">
                    <Building2 className="w-8 h-8 text-indigo-400" />
                   </div>
                   <div className="space-y-2">
                    <p className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.4em]">Subscribed Tier</p>
                    <h3 className="text-4xl font-black tracking-tight leading-tight uppercase">Enterprise Plus</h3>
                   </div>
                   <p className="text-slate-400 font-medium leading-relaxed italic pr-10">Unlimited personnel nodes across global data centers with prioritized system support.</p>
                   <div className="pt-8">
                      <button className="flex items-center gap-4 bg-white text-slate-900 px-8 py-5 rounded-2xl font-black text-[11px] uppercase tracking-widest shadow-2xl hover:scale-105 active:scale-95 transition-all">
                        Portal Direct Admin
                        <ArrowRight className="w-4 h-4" />
                      </button>
                   </div>
                 </div>
              </motion.div>
            )}
          </div>
        </div>

        {/* Info Sidebar */}
        <div className="space-y-8">
          <div className="bg-white rounded-[3rem] p-10 border border-slate-100 shadow-2xl shadow-slate-200/20">
            <h4 className="text-sm font-black tracking-tight mb-8 uppercase flex items-center gap-3">
              <PlusCircle className="w-5 h-5 text-indigo-500" />
              Quick Modules
            </h4>
            <div className="space-y-4">
              {[
                { label: 'Cloud Backups', active: true },
                { label: 'API Gateway', active: false },
                { label: 'Audit Logs', active: true },
              ].map((mod, i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{mod.label}</span>
                  <div className={cn("w-2 h-2 rounded-full", mod.active ? 'bg-emerald-500 shadow-lg shadow-emerald-200' : 'bg-slate-300')} />
                </div>
              ))}
            </div>
            
            <div className="mt-10 pt-10 border-t border-slate-50 space-y-6">
               <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Usage Limit</span>
                  <span className="text-[10px] font-black text-slate-900 tracking-widest">85%</span>
               </div>
               <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: '85%' }}
                    className="h-full bg-slate-900" 
                  />
               </div>
               <p className="text-[9px] font-bold text-slate-400 uppercase tracking-[0.1em] text-center italic">12.5GB / 15.0GB utilized</p>
            </div>
          </div>

          <div className="bg-rose-50 rounded-[3rem] p-10 border border-rose-100 shadow-xl shadow-rose-100/10">
             <div className="w-12 h-12 bg-rose-100 text-rose-600 rounded-2xl flex items-center justify-center mb-6">
               <Trash2 className="w-6 h-6" />
             </div>
             <h4 className="font-black text-rose-950 uppercase tracking-tight mb-4 text-base">Terminal Destruct</h4>
             <p className="text-[11px] font-medium text-rose-600/80 leading-relaxed mb-10 uppercase tracking-wide">Permanently purge all organizational data packets from global storage clusters.</p>
             <button className="w-full py-4 border-2 border-rose-200 text-rose-600 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-rose-600 hover:text-white hover:border-rose-600 transition-all shadow-sm">Initiate Termination</button>
          </div>
        </div>
      </div>
    </div>
  );
}

const ToggleSetting = ({ title, description, active }: { title: string, description: string, active: boolean }) => {
  const [enabled, setEnabled] = useState(active);
  return (
    <div className="group flex items-center justify-between p-6 bg-slate-50/50 hover:bg-white border border-slate-50 hover:border-slate-100 rounded-3xl transition-all cursor-pointer" onClick={() => setEnabled(!enabled)}>
      <div className="space-y-1">
        <p className="text-[11px] font-black text-slate-900 uppercase tracking-tighter">{title}</p>
        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tight leading-relaxed max-w-[280px]">{description}</p>
      </div>
      <div className={cn(
        "relative w-12 h-7 rounded-full transition-all duration-300",
        enabled ? "bg-slate-900" : "bg-slate-200"
      )}>
        <motion.div 
          animate={{ x: enabled ? 22 : 4 }}
          transition={{ type: 'spring', damping: 20, stiffness: 300 }}
          className="absolute top-1 w-5 h-5 bg-white rounded-full shadow-lg"
        />
      </div>
    </div>
  );
};
