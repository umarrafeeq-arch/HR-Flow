import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot, getDocs, setDoc, doc, deleteDoc, addDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { useAuth } from '../../lib/AuthContext';
import { Employee, AttendanceRecord } from '../../types';
import { Calendar, ChevronLeft, ChevronRight, Check, X, Clock, AlertCircle, Users, UserCheck, UserX, UserMinus, ArrowRight } from 'lucide-react';
import { format, addDays, subDays, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ');
}

export default function AttendancePage() {
  const { profile } = useAuth();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [attendance, setAttendance] = useState<Record<string, any>>({});
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile?.organizationId) return;

    // Load employees
    const qEmp = query(collection(db, 'employees'), where('organizationId', '==', profile.organizationId));
    const unsubscribeEmp = onSnapshot(qEmp, (snapshot) => {
      setEmployees(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Employee)));
    });

    // Load attendance for selected date
    const dateStr = format(selectedDate, 'yyyy-MM-dd');
    const qAtt = query(
      collection(db, 'attendance'), 
      where('organizationId', '==', profile.organizationId),
      where('date', '==', dateStr)
    );
    
    const unsubscribeAtt = onSnapshot(qAtt, (snapshot) => {
      const attMap: Record<string, any> = {};
      snapshot.docs.forEach(doc => {
        const data = doc.data();
        attMap[data.employeeId] = { docId: doc.id, ...data };
      });
      setAttendance(attMap);
      setLoading(false);
    });

    return () => {
      unsubscribeEmp();
      unsubscribeAtt();
    };
  }, [profile, selectedDate]);

  const markAttendance = async (employeeId: string, status: string) => {
    if (!profile?.organizationId) return;
    const dateStr = format(selectedDate, 'yyyy-MM-dd');
    const existing = attendance[employeeId];

    try {
      if (existing) {
        if (existing.status === status) {
          // Toggle off (delete)
          await deleteDoc(doc(db, 'attendance', existing.docId));
        } else {
          // Update
          await setDoc(doc(db, 'attendance', existing.docId), { 
            ...existing, 
            status, 
            updatedAt: new Date().toISOString() 
          }, { merge: true });
        }
      } else {
        // Create new
        await addDoc(collection(db, 'attendance'), {
          employeeId,
          organizationId: profile.organizationId,
          date: dateStr,
          status,
          inTime: status === 'Present' ? '09:00' : null,
          outTime: status === 'Present' ? '18:00' : null,
          createdAt: new Date().toISOString()
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'attendance');
    }
  };

  const updateTime = async (atDocId: string, field: 'inTime' | 'outTime', value: string) => {
    try {
      await setDoc(doc(db, 'attendance', atDocId), { [field]: value }, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `attendance/${atDocId}`);
    }
  };

  const presentCount = Object.values(attendance).filter((r: any) => r.status === 'Present').length;
  const absentCount = Object.values(attendance).filter((r: any) => r.status === 'Absent').length;
  const leaveCount = Object.values(attendance).filter((r: any) => r.status === 'Leave').length;

  return (
    <div className="max-w-[1600px] mx-auto space-y-8 pb-20">
      {/* Page Header & Date Nav */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-10 bg-white p-8 sm:p-10 rounded-[3rem] border border-slate-100 shadow-2xl shadow-slate-200/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-10 opacity-[0.02] pointer-events-none">
          <Calendar className="w-64 h-64 text-slate-900" />
        </div>
        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-3">
            <span className="h-0.5 w-8 bg-slate-200" />
            <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.3em]">Temporal Logistics</span>
          </div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tighter leading-none uppercase">Attendance</h1>
          <p className="text-slate-400 font-bold text-sm max-w-md">Mark and monitor daily presence logs across the organization terminal.</p>
        </div>
        
        <div className="flex items-center gap-2 bg-slate-900 p-2.5 rounded-[2rem] border border-slate-800 shadow-2xl shadow-slate-200 relative z-10">
          <motion.button 
            whileHover={{ scale: 1.1 }}
            whileActive={{ scale: 0.9 }}
            onClick={() => setSelectedDate(subDays(selectedDate, 1))}
            className="p-3 text-slate-400 hover:text-white transition-all"
          >
            <ChevronLeft className="w-6 h-6" />
          </motion.button>
          
          <div className="flex items-center gap-4 px-8 py-1 border-x border-slate-800">
            <Calendar className="w-5 h-5 text-indigo-400" />
            <span className="font-black text-white min-w-[160px] text-center uppercase tracking-[0.2em] text-[10px]">
              {format(selectedDate, 'MMM dd, yyyy')}
            </span>
          </div>
          
          <motion.button 
            whileHover={{ scale: 1.1 }}
            whileActive={{ scale: 0.9 }}
            onClick={() => setSelectedDate(addDays(selectedDate, 1))}
            className="p-3 text-slate-400 hover:text-white transition-all"
          >
            <ChevronRight className="w-6 h-6" />
          </motion.button>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-10 items-start">
        {/* Main Attendance List */}
        <div className="lg:col-span-3 space-y-8">
          {/* Desktop Table */}
          <div className="hidden md:block bg-white rounded-[3rem] border border-slate-100 shadow-2xl shadow-slate-200/20 overflow-hidden">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50/30 border-b border-slate-50">
                  <th className="pl-10 pr-4 py-8 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">Authorized Personnel</th>
                  <th className="px-4 py-8 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">Presence Authorization</th>
                  <th className="px-4 py-8 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">Deployment Logs</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                <AnimatePresence mode="popLayout">
                  {employees.map((emp) => {
                    const record = attendance[emp.id];
                    return (
                      <motion.tr 
                        layout
                        key={emp.id} 
                        className="hover:bg-slate-50/20 transition-all group cursor-default"
                      >
                        <td className="pl-10 pr-4 py-6">
                          <div className="flex items-center gap-5">
                            <div className="w-14 h-14 bg-slate-50 border border-slate-100 rounded-2xl flex items-center justify-center p-0.5 group-hover:scale-105 transition-transform">
                               <div className="w-full h-full rounded-[14px] bg-slate-900 text-white flex items-center justify-center font-black text-xs">
                                {emp.name?.[0]}
                               </div>
                            </div>
                            <div>
                              <p className="font-black text-slate-900 uppercase tracking-tight text-sm group-hover:text-indigo-600 transition-colors">{emp.name}</p>
                              <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest mt-0.5">{emp.designation}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-6">
                          <div className="flex gap-2">
                            <StatusBtn 
                              active={record?.status === 'Present'} 
                              onClick={() => markAttendance(emp.id, 'Present')}
                              variant="emerald"
                              label="Active"
                              icon={UserCheck}
                            />
                            <StatusBtn 
                              active={record?.status === 'Absent'} 
                              onClick={() => markAttendance(emp.id, 'Absent')}
                              variant="rose"
                              label="Absent"
                              icon={UserX}
                            />
                            <StatusBtn 
                              active={record?.status === 'Leave'} 
                              onClick={() => markAttendance(emp.id, 'Leave')}
                              variant="amber"
                              label="Except"
                              icon={UserMinus}
                            />
                          </div>
                        </td>
                        <td className="px-4 py-6">
                          {record?.status === 'Present' ? (
                            <div className="flex items-center gap-4">
                              <div className="relative group/time flex-1 max-w-[140px]">
                                <Clock className="absolute left-4 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-indigo-400" />
                                <input 
                                  type="time"
                                  value={record.inTime || '09:00'}
                                  onChange={(e) => updateTime(record.docId, 'inTime', e.target.value)}
                                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-[14px] outline-none focus:ring-8 focus:ring-slate-100/50 focus:border-slate-300 text-[10px] font-black text-slate-900 transition-all cursor-pointer uppercase tracking-widest"
                                />
                              </div>
                              <ArrowRight className="w-4 h-4 text-slate-200" />
                              <div className="relative group/time flex-1 max-w-[140px]">
                                <Clock className="absolute left-4 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-rose-400" />
                                <input 
                                  type="time"
                                  value={record.outTime || '18:00'}
                                  onChange={(e) => updateTime(record.docId, 'outTime', e.target.value)}
                                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-[14px] outline-none focus:ring-8 focus:ring-slate-100/50 focus:border-slate-300 text-[10px] font-black text-slate-900 transition-all cursor-pointer uppercase tracking-widest"
                                />
                              </div>
                            </div>
                          ) : (
                            <div className="h-12 flex items-center px-6 bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
                               <span className="text-[9px] font-black text-slate-300 uppercase tracking-[0.2em]">Operational Lockdown</span>
                            </div>
                          )}
                        </td>
                      </motion.tr>
                    );
                  })}
                </AnimatePresence>
                {employees.length === 0 && !loading && (
                  <tr>
                    <td colSpan={3} className="py-32 text-center">
                       <div className="w-20 h-20 bg-slate-50 rounded-3xl flex items-center justify-center mx-auto mb-6">
                        <Users className="w-10 h-10 text-slate-200" />
                       </div>
                       <p className="text-slate-400 font-black uppercase tracking-[0.2em] text-[10px]">No infrastructure nodes detected</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Mobile Card Stack */}
          <div className="md:hidden space-y-6">
            {employees.map((emp) => {
              const record = attendance[emp.id];
              return (
                <div key={emp.id} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-2xl shadow-slate-200/10 space-y-8">
                  <div className="flex items-center gap-5">
                    <div className="w-14 h-14 bg-slate-900 rounded-2xl flex items-center justify-center font-black text-white shadow-lg">
                      {emp.name?.[0]}
                    </div>
                    <div>
                      <h4 className="font-black text-slate-900 uppercase tracking-tighter text-base">{emp.name}</h4>
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">{emp.designation}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-3">
                    <div className="flex gap-2">
                       <button 
                        onClick={() => markAttendance(emp.id, 'Present')}
                        className={cn(
                          "flex-1 flex items-center justify-center gap-3 p-4 rounded-2xl border transition-all font-black text-[10px] uppercase tracking-widest",
                          record?.status === 'Present' ? "bg-emerald-600 border-emerald-600 text-white shadow-xl shadow-emerald-100" : "bg-white border-slate-100 text-slate-400"
                        )}
                      >
                        <UserCheck className="w-4 h-4" />
                        Active
                      </button>
                      <button 
                        onClick={() => markAttendance(emp.id, 'Absent')}
                        className={cn(
                          "flex-1 flex items-center justify-center gap-3 p-4 rounded-2xl border transition-all font-black text-[10px] uppercase tracking-widest",
                          record?.status === 'Absent' ? "bg-rose-600 border-rose-600 text-white shadow-xl shadow-rose-100" : "bg-white border-slate-100 text-slate-400"
                        )}
                      >
                        <UserX className="w-4 h-4" />
                        Absent
                      </button>
                    </div>
                    <button 
                      onClick={() => markAttendance(emp.id, 'Leave')}
                      className={cn(
                        "w-full flex items-center justify-center gap-3 p-4 rounded-2xl border transition-all font-black text-[10px] uppercase tracking-widest",
                        record?.status === 'Leave' ? "bg-amber-500 border-amber-500 text-white shadow-xl shadow-amber-100" : "bg-white border-slate-100 text-slate-400"
                      )}
                    >
                      <UserMinus className="w-4 h-4" />
                      Exception
                    </button>
                  </div>

                  {record?.status === 'Present' && (
                    <div className="space-y-4 p-5 bg-slate-50 rounded-[2rem] border border-slate-100">
                      <div>
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-3 ml-1">Terminal In</p>
                        <div className="relative">
                          <Clock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-indigo-400" />
                          <input 
                            type="time"
                            value={record.inTime || '09:00'}
                            onChange={(e) => updateTime(record.docId, 'inTime', e.target.value)}
                            className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-2xl outline-none font-black text-xs text-slate-900 uppercase tracking-widest"
                          />
                        </div>
                      </div>
                      <div>
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-3 ml-1 text-right">Terminal Out</p>
                        <div className="relative">
                          <Clock className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-rose-400" />
                          <input 
                            type="time"
                            value={record.outTime || '18:00'}
                            onChange={(e) => updateTime(record.docId, 'outTime', e.target.value)}
                            className="w-full pr-12 pl-4 py-4 bg-white border border-slate-200 rounded-2xl outline-none font-black text-xs text-slate-900 uppercase tracking-widest text-right"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Sidebar Summary */}
        <div className="space-y-8 lg:sticky lg:top-[120px]">
           <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-2xl shadow-slate-200/30">
             <div className="flex items-center gap-4 mb-10">
               <div className="w-12 h-12 bg-slate-900 text-indigo-400 rounded-2xl flex items-center justify-center shadow-lg">
                 <AlertCircle className="w-6 h-6" />
               </div>
               <div>
                <h3 className="text-sm font-black text-slate-900 tracking-tight uppercase">Daily Pulse</h3>
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Real-time sync</p>
               </div>
             </div>

             <div className="space-y-6">
                <SummaryRow label="Active Nodes" count={presentCount} theme="emerald" />
                <SummaryRow label="Offline Units" count={absentCount} theme="rose" />
                <SummaryRow label="Deployment Exp" count={leaveCount} theme="amber" />
                
                <div className="pt-8 mt-8 border-t border-slate-50 flex items-center justify-between">
                  <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Cluster</p>
                    <p className="text-3xl font-black text-slate-900 mt-1 tracking-tighter">{employees.length}</p>
                  </div>
                  <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-300">
                    <Users className="w-8 h-8" />
                  </div>
                </div>

                <div className="mt-6 p-6 bg-slate-50/50 rounded-[2rem] border border-slate-100">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Load Density</span>
                    <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em]">
                      {employees.length ? Math.round((Object.keys(attendance).length / employees.length) * 100) : 0}%
                    </span>
                  </div>
                  <div className="h-2.5 bg-slate-200 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: employees.length ? `${(Object.keys(attendance).length / employees.length) * 100}%` : '0%' }}
                      className="h-full bg-slate-900"
                    />
                  </div>
                </div>
             </div>
           </div>

           <div className="bg-indigo-600 rounded-[3rem] p-10 text-white relative overflow-hidden shadow-2xl shadow-indigo-200/50 group">
             <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform duration-1000">
               <Clock className="w-32 h-32" />
             </div>
             <p className="text-[10px] font-black text-indigo-200 uppercase tracking-[0.3em] mb-6 underline decoration-indigo-400 underline-offset-8">System Manual</p>
             <h4 className="text-xl font-black leading-tight mb-4 tracking-tight uppercase">Protocol: Status Toggle</h4>
             <p className="text-indigo-100 text-xs font-medium leading-relaxed opacity-90">
               Double-tap any designation to purge the record. Logs are pushed to global sync instantly.
             </p>
             <motion.div 
              whileHover={{ x: 5 }}
              className="mt-10 flex items-center gap-3 text-white text-[10px] font-black uppercase tracking-widest cursor-pointer group"
             >
               View Full Report
               <ArrowRight className="w-4 h-4 text-indigo-300" />
             </motion.div>
           </div>
        </div>
      </div>
    </div>
  );
}

const StatusBtn = ({ active, onClick, variant, label, icon: Icon }: any) => {
  const themes: any = {
    emerald: active ? 'bg-emerald-600 text-white border-emerald-600 shadow-lg shadow-emerald-100/50' : 'bg-white text-emerald-600 border-emerald-100 hover:bg-emerald-50 hover:scale-105 active:scale-95',
    rose: active ? 'bg-rose-600 text-white border-rose-600 shadow-lg shadow-rose-100/50' : 'bg-white text-rose-600 border-rose-100 hover:bg-rose-50 hover:scale-105 active:scale-95',
    amber: active ? 'bg-amber-500 text-white border-amber-500 shadow-lg shadow-amber-100/50' : 'bg-white text-amber-500 border-amber-100 hover:bg-amber-50 hover:scale-105 active:scale-95',
  };

  return (
    <button 
      onClick={onClick}
      className={cn(
        "px-4 py-2 rounded-xl border font-black text-[10px] uppercase tracking-widest transition-all flex items-center gap-2",
        themes[variant]
      )}
    >
      <Icon className={cn("w-3.5 h-3.5", active ? "text-white" : "")} />
      {label}
    </button>
  );
};

const SummaryRow = ({ label, count, theme }: any) => {
  const dots: any = {
    emerald: 'bg-emerald-500',
    rose: 'bg-rose-500',
    amber: 'bg-amber-500'
  };
  return (
    <div className="flex items-center justify-between p-4 bg-slate-50/50 rounded-2xl border border-slate-100">
      <div className="flex items-center gap-3">
        <div className={cn("w-2 h-2 rounded-full", dots[theme])} />
        <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{label}</span>
      </div>
      <span className="text-sm font-black text-slate-900">{count}</span>
    </div>
  );
};

