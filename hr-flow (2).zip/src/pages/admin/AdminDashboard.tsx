import React, { useEffect, useState } from 'react';
import { collection, query, orderBy, onSnapshot, doc, updateDoc, setDoc, serverTimestamp, deleteDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import { OrganizationRequest, Organization } from '../../types';
import { Check, X, Building, Users, Clock, Plus, Shield, ExternalLink, Trash2, Globe, Sparkles, Building2, ChevronRight, Search, Activity, Mail, User } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ');
}

export default function AdminDashboard() {
  const [requests, setRequests] = useState<OrganizationRequest[]>([]);
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [showOrgModal, setShowOrgModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<OrganizationRequest | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const qRequests = query(collection(db, 'organization_requests'), orderBy('createdAt', 'desc'));
    const unsubscribeReq = onSnapshot(qRequests, (snapshot) => {
      setRequests(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as OrganizationRequest)));
      setLoading(false);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'organization_requests'));

    const qOrgs = query(collection(db, 'organizations'), orderBy('createdAt', 'desc'));
    const unsubscribeOrgs = onSnapshot(qOrgs, (snapshot) => {
      setOrganizations(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Organization)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'organizations'));

    return () => {
      unsubscribeReq();
      unsubscribeOrgs();
    };
  }, []);

  const handleApprove = async (request: OrganizationRequest) => {
    setSelectedRequest(request);
    setShowOrgModal(true);
  };

  const handleReject = async (requestId: string) => {
    if (!confirm('Are you sure you want to reject this request?')) return;
    try {
      await updateDoc(doc(db, 'organization_requests', requestId), { status: 'rejected' });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `organization_requests/${requestId}`);
    }
  };

  const finalizeApproval = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRequest) return;
    
    const form = e.target as HTMLFormElement;
    const orgId = (form.elements.namedItem('orgId') as HTMLInputElement).value;
    const hrUid = (form.elements.namedItem('hrUid') as HTMLInputElement).value;

    try {
      const orgRef = doc(db, 'organizations', orgId);
      await setDoc(orgRef, {
        organizationId: orgId,
        companyName: selectedRequest.companyName,
        hrId: hrUid,
        createdAt: serverTimestamp(),
        createdBy: 'admin'
      });

      // Update user record for the HR
      await setDoc(doc(db, 'users', hrUid), {
        name: selectedRequest.hrName,
        email: selectedRequest.hrEmail,
        role: 'hr',
        organizationId: orgId
      });

      // Update request status
      await updateDoc(doc(db, 'organization_requests', selectedRequest.id), { status: 'approved' });

      setShowOrgModal(false);
      setSelectedRequest(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'organizations/users');
    }
  };

  return (
    <div className="max-w-[1600px] mx-auto space-y-10 pb-20">
      {/* Admin Title Section */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-6 bg-white p-6 sm:p-10 rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
          <Shield className="w-48 h-48 text-indigo-600" />
        </div>
        <div className="relative z-10 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-3 py-1 bg-amber-50 text-amber-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-amber-100">Root Access</span>
            <span className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-indigo-100">System v2.4</span>
          </div>
          <h1 className="text-2xl xs:text-3xl sm:text-4xl font-black text-slate-900 tracking-tight leading-none uppercase tracking-tighter">Mission Control</h1>
          <p className="text-slate-500 font-medium max-w-xl text-xs sm:text-base leading-relaxed">Global oversight of all organizational request cycles and enterprise accounts.</p>
        </div>

        <div className="grid grid-cols-2 lg:flex items-center gap-3 sm:gap-4 relative z-10">
          <StatMini label="Active Orgs" value={organizations.length} icon={Building2} color="indigo" />
          <StatMini label="Pending" value={requests.filter(r => r.status === 'pending').length} icon={Clock} color="amber" />
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8 items-start">
        {/* Left Column: Requests */}
        <div className="space-y-6">
          <div className="flex items-center justify-between px-6">
            <h2 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-500" />
              Ingress Queue
            </h2>
            <div className="px-3 py-1 bg-white border border-slate-100 rounded-full text-[8px] font-bold text-slate-400 uppercase tracking-widest">Live Updates</div>
          </div>

          <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/20 overflow-hidden min-h-[400px]">
            <AnimatePresence mode="popLayout" initial={false}>
              {requests.filter(r => r.status === 'pending').map((req, idx) => (
                <motion.div 
                  key={req.id}
                  layout
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ delay: idx * 0.05 }}
                  className="p-5 sm:p-8 border-b border-slate-50 hover:bg-slate-50/50 transition-all group"
                >
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
                    <div className="flex items-center gap-4 sm:gap-5 w-full">
                      <div className="w-12 h-12 sm:w-14 sm:h-14 bg-white border border-slate-100 rounded-xl sm:rounded-2xl flex-shrink-0 flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                        <Building className="w-6 h-6 sm:w-7 sm:h-7 text-indigo-600" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <h4 className="text-base sm:text-lg font-black text-slate-900 tracking-tight leading-none uppercase tracking-tighter truncate">{req.companyName}</h4>
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 mt-2">
                          <span className="flex items-center gap-1.5 text-xs font-bold text-slate-400">
                             <User className="w-3 h-3" /> {req.hrName}
                          </span>
                          <span className="hidden xs:block w-1 h-1 bg-slate-200 rounded-full" />
                          <span className="text-xs font-bold text-slate-400 lowercase truncate max-w-[150px] sm:max-w-none">{req.hrEmail}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 w-full sm:w-auto mt-2 sm:mt-0">
                      <button 
                        onClick={() => handleReject(req.id)}
                        className="flex-1 sm:flex-none p-3.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-2xl transition-all border border-slate-100 sm:border-transparent hover:border-rose-100"
                        title="Reject Request"
                      >
                        <X className="w-5 h-5 mx-auto" />
                      </button>
                      <button 
                        onClick={() => handleApprove(req)}
                        className="flex-[3] sm:flex-none flex items-center justify-center gap-2 px-6 py-3.5 bg-indigo-600 text-white rounded-2xl hover:bg-indigo-700 transition-all font-black text-[10px] uppercase tracking-widest shadow-lg shadow-indigo-100 group-hover:scale-105 active:scale-95"
                      >
                        <Check className="w-4 h-4" />
                        <span className="whitespace-nowrap">Provision Access</span>
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
              {requests.filter(r => r.status === 'pending').length === 0 && !loading && (
                <div className="flex flex-col items-center justify-center p-20 text-center">
                  <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-[2rem] flex items-center justify-center mb-6 border border-emerald-100">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>
                  <h4 className="font-black text-slate-900 uppercase tracking-tighter text-xl">Queue Clear</h4>
                  <p className="text-slate-400 font-medium text-sm mt-1">Status: All requests processed.</p>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Right Column: Existing Orgs */}
        <div className="space-y-6">
          <div className="flex items-center justify-between px-6">
            <h2 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
              <Building2 className="w-4 h-4 text-indigo-500" />
              Active Ecosystem
            </h2>
          </div>

          <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/20 overflow-hidden">
             {organizations.length > 0 ? (
               <div className="divide-y divide-slate-50">
                 {organizations.map((org) => (
                   <div key={org.id} className="p-6 sm:p-8 hover:bg-slate-50 transition-all group flex items-center justify-between gap-4">
                     <div className="flex items-center gap-4 sm:gap-6 min-w-0">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 bg-indigo-600 rounded-xl sm:rounded-[1.25rem] flex-shrink-0 flex items-center justify-center text-white font-black text-lg sm:text-xl shadow-lg shadow-indigo-100 group-hover:rotate-12 transition-transform">
                          {org.companyName?.[0]}
                        </div>
                        <div className="min-w-0">
                          <p className="font-black text-slate-900 tracking-tight uppercase tracking-tighter truncate">{org.companyName}</p>
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1 truncate">ID: {org.organizationId}</p>
                        </div>
                     </div>
                     <div className="flex items-center gap-1 sm:gap-2 opacity-0 group-hover:opacity-100 group-hover:translate-x-0 translate-x-2 transition-all">
                        <button className="p-2 sm:p-2.5 text-slate-400 hover:text-indigo-600 hover:bg-white hover:shadow-sm rounded-xl transition-all border border-transparent hover:border-slate-100">
                          <ExternalLink className="w-4 h-4 sm:w-5 sm:h-5" />
                        </button>
                        <button className="p-2 sm:p-2.5 text-slate-400 hover:text-rose-600 hover:bg-white hover:shadow-sm rounded-xl transition-all border border-transparent hover:border-slate-100">
                          <Trash2 className="w-4 h-4 sm:w-5 sm:h-5" />
                        </button>
                     </div>
                   </div>
                 ))}
               </div>
             ) : (
               <div className="p-20 text-center">
                  <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">No active nodes detected.</p>
               </div>
             )}
          </div>
        </div>
      </div>

      {/* Approval Modal */}
      <AnimatePresence>
        {showOrgModal && (
          <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-[2rem] sm:rounded-[3rem] p-6 sm:p-12 max-w-xl w-full shadow-2xl relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-8 opacity-5 text-indigo-600 hidden sm:block">
                <Plus className="w-32 h-32" />
              </div>
              
              <div className="relative z-10">
                <div className="flex items-center gap-4 mb-8 sm:mb-10">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-indigo-50 text-indigo-600 rounded-xl sm:rounded-2xl flex items-center justify-center">
                    <Sparkles className="w-5 h-5 sm:w-6 sm:h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight leading-none uppercase tracking-tighter">Provisioning Hub</h3>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">ID Generation Strategy</p>
                  </div>
                </div>

                <form onSubmit={finalizeApproval} className="space-y-6 sm:space-y-8">
                  <div className="bg-indigo-50/50 p-4 sm:p-6 rounded-2xl sm:rounded-3xl border border-indigo-100/50">
                    <div className="flex gap-3 sm:gap-4">
                      <div className="w-8 h-8 sm:w-10 sm:h-10 bg-indigo-100 text-indigo-600 rounded-lg sm:rounded-xl flex-shrink-0 flex items-center justify-center">
                        <Mail className="w-4 h-4 sm:w-5 sm:h-5" />
                      </div>
                      <p className="text-[10px] sm:text-xs text-indigo-900/70 font-bold leading-relaxed">
                        Security Notice: Create credentials for <span className="text-indigo-600 underline font-black truncate inline-block max-w-[150px] sm:max-w-none align-bottom">{selectedRequest?.hrEmail}</span> before entering UID.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-5 sm:gap-6">
                    <div className="space-y-2.5">
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Internal Cluster ID</label>
                      <input 
                        name="orgId"
                        required
                        placeholder="e.g. acme-global"
                        className="w-full px-5 sm:px-6 py-4 bg-slate-50 border border-slate-100 rounded-xl sm:rounded-2xl outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 font-black text-slate-900"
                      />
                    </div>

                    <div className="space-y-2.5">
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">HR Security UID</label>
                      <input 
                        name="hrUid"
                        required
                        placeholder="Firebase Auth UID"
                        className="w-full px-5 sm:px-6 py-4 bg-slate-50 border border-slate-100 rounded-xl sm:rounded-2xl outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 font-black text-slate-900"
                      />
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 pt-4">
                    <button 
                      type="button"
                      onClick={() => setShowOrgModal(false)}
                      className="order-2 sm:order-1 flex-1 py-4 sm:py-5 bg-white text-slate-400 rounded-xl sm:rounded-2xl font-black text-[10px] uppercase tracking-widest border border-slate-100 hover:bg-slate-50 transition-colors"
                    >
                      Abort
                    </button>
                    <button 
                      type="submit"
                      className="order-1 sm:order-2 flex-1 py-4 sm:py-5 bg-indigo-600 text-white rounded-xl sm:rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95"
                    >
                      Authorize Node
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

const StatMini = ({ label, value, icon: Icon, color }: any) => {
  const colorMap = {
    indigo: "bg-indigo-50 text-indigo-600 border-indigo-100",
    amber: "bg-amber-50 text-amber-600 border-amber-100",
  } as any;

  return (
    <div className={cn("px-3 sm:px-5 py-2 sm:py-3 bg-white rounded-2xl sm:rounded-3xl border flex items-center gap-3 sm:gap-4 transition-all hover:shadow-md", colorMap[color])}>
      <div className={cn("w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0", `bg-white/50 backdrop-blur-sm shadow-sm`)}>
        <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
      </div>
      <div className="min-w-0">
        <p className="text-[8px] sm:text-[9px] font-black uppercase tracking-widest opacity-60 leading-none truncate">{label}</p>
        <p className="text-lg sm:text-xl font-black tracking-tight leading-none mt-1">{value}</p>
      </div>
    </div>
  );
};

const CheckCircle2 = (props: any) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
);
