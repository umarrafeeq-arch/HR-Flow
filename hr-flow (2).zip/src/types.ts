export type UserRole = 'super_admin' | 'hr' | 'employee';

export interface UserProfile {
  uid: string;
  email: string;
  name: string;
  role: UserRole;
  organizationId?: string;
}

export interface OrganizationRequest {
  id: string;
  companyName: string;
  hrName: string;
  hrEmail: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: any;
}

export interface Organization {
  id: string;
  companyName: string;
  hrId: string;
  createdAt: any;
}

export interface Employee {
  id: string;
  name: string;
  designation: string;
  organizationId: string;
  joiningDate: string;
}

export interface AttendanceRecord {
  status: 'Present' | 'Absent' | 'Leave';
  inTime?: string;
  outTime?: string;
  workingHours?: number;
  date: string;
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  leaveType: string;
  startDate: string;
  endDate: string;
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  organizationId: string;
  createdAt: string;
}
