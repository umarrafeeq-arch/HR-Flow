import React, { useState, useEffect, lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link, useNavigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './lib/AuthContext';
import { LogOut, LayoutDashboard, Users, Calendar, FileText, Settings as SettingsIcon, PlusCircle, Building2, Bell, CheckCircle2, XCircle, Menu, X, ChevronRight, Search, User as UserIcon, Loader2 } from 'lucide-react';
import { auth } from './lib/firebase';
import { signOut } from 'firebase/auth';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Lazy Pages
const LoginPage = lazy(() => import('./pages/LoginPage'));
const RegistrationRequestPage = lazy(() => import('./pages/RegistrationRequestPage'));
const AdminDashboard = lazy(() => import('./pages/admin/AdminDashboard'));
const HRDashboard = lazy(() => import('./pages/hr/HRDashboard'));
const EmployeeList = lazy(() => import('./pages/hr/EmployeeList'));
const AttendancePage = lazy(() => import('./pages/hr/AttendancePage'));
const ReportsPage = lazy(() => import('./pages/hr/ReportsPage'));
const LeaveManagement = lazy(() => import('./pages/hr/LeaveManagement'));
const Settings = lazy(() => import('./pages/hr/Settings'));

const PageLoader = () => (
  <div className="flex items-center justify-center min-h-[400px]">
    <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
  </div>
);

const SidebarLink = ({ to, icon: Icon, children, onClick }: { to: string, icon: any, children: React.ReactNode, onClick?: () => void }) => {
  const location = useLocation();
  const isActive = location.pathname === to;
  
  return (
    <Link 
      to={to} 
      onClick={onClick}
      className={cn(
        "flex items-center gap-3 px-4 py-3 sm:py-3.5 rounded-2xl transition-all duration-300 group relative",
        isActive 
          ? "bg-slate-900 text-white shadow-xl shadow-slate-200" 
          : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
      )}
    >
      <Icon className={cn("w-5 h-5", !isActive && "group-hover:scale-110 group-hover:rotate-3 transition-all duration-300")} />
      <span className="font-bold text-xs uppercase tracking-widest">{children}</span>
      {isActive && (
        <motion.div 
          layoutId="sidebar-active"
          className="absolute right-3 w-1.5 h-1.5 bg-indigo-400 rounded-full"
        />
      )}
    </Link>
  );
};

const Navigation = ({ closeMenu }: { closeMenu?: () => void }) => {
  const { profile, isAdmin, isHR } = useAuth();
  
  return (
    <nav className="space-y-1.5">
      <div className="px-4 mb-4">
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Main Menu</p>
      </div>
      {isAdmin && (
        <>
          <SidebarLink onClick={closeMenu} to="/admin" icon={LayoutDashboard}>Admin Console</SidebarLink>
          <SidebarLink onClick={closeMenu} to="/admin/organizations" icon={Building2}>Organizations</SidebarLink>
        </>
      )}
      {isHR && (
        <>
          <SidebarLink onClick={closeMenu} to="/hr" icon={LayoutDashboard}>Overview</SidebarLink>
          <SidebarLink onClick={closeMenu} to="/hr/employees" icon={Users}>Team Directory</SidebarLink>
          <SidebarLink onClick={closeMenu} to="/hr/attendance" icon={Calendar}>Attendance</SidebarLink>
          <SidebarLink onClick={closeMenu} to="/hr/leaves" icon={CheckCircle2}>Leave Requests</SidebarLink>
          <SidebarLink onClick={closeMenu} to="/hr/reports" icon={FileText}>Analytics</SidebarLink>
        </>
      )}
      <div className="px-4 mt-8 mb-4">
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">System</p>
      </div>
      <SidebarLink onClick={closeMenu} to="/settings" icon={SettingsIcon}>Organization Settings</SidebarLink>
    </nav>
  );
};

const OfflineBanner = () => {
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (!isOffline) return null;

  return (
    <motion.div 
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed top-0 inset-x-0 z-[60] bg-rose-600 text-white py-3 px-6 flex items-center justify-center gap-3 shadow-2xl"
    >
      <WifiOff className="w-4 h-4 animate-pulse" />
      <span className="text-[10px] font-black uppercase tracking-widest">Network Interrupted — Local Cache Active</span>
    </motion.div>
  );
};

const BottomNav = () => {
  const { profile, isHR } = useAuth();
  const location = useLocation();

  if (!profile) return null;

  const NavItem = ({ to, icon: Icon, label }: any) => {
    const isActive = location.pathname === to;
    return (
      <Link 
        to={to} 
        className={cn(
          "flex flex-col items-center gap-1 flex-1 py-1 transition-all",
          isActive ? "text-slate-900" : "text-slate-400"
        )}
      >
        <div className={cn(
          "p-2 rounded-xl transition-all",
          isActive ? "bg-slate-100 scale-110 shadow-sm" : ""
        )}>
          <Icon className="w-5 h-5" />
        </div>
        <span className="text-[8px] font-black uppercase tracking-tighter">{label}</span>
      </Link>
    );
  };

  return (
    <div className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-white/80 backdrop-blur-xl border-t border-slate-100 px-2 pb-safe-area-inset-bottom pt-2 flex items-center justify-between shadow-[0_-10px_30px_-15px_rgba(0,0,0,0.1)]">
      {isHR ? (
        <>
          <NavItem to="/hr" icon={LayoutDashboard} label="Ops" />
          <NavItem to="/hr/employees" icon={Users} label="Team" />
          <NavItem to="/hr/attendance" icon={Calendar} label="Time" />
          <NavItem to="/hr/leaves" icon={CheckCircle2} label="Leads" />
          <NavItem to="/settings" icon={SettingsIcon} label="System" />
        </>
      ) : (
        <>
          <NavItem to="/admin" icon={LayoutDashboard} label="Root" />
          <NavItem to="/admin/organizations" icon={Building2} label="Orgs" />
          <NavItem to="/settings" icon={SettingsIcon} label="System" />
        </>
      )}
    </div>
  );
};

const InstallPrompt = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      // Wait a bit before showing to avoid annoying the user immediately
      setTimeout(() => setIsVisible(true), 5000);
    };

    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsVisible(false);
    }
    setDeferredPrompt(null);
  };

  if (!isVisible) return null;

  return (
    <motion.div 
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed bottom-24 lg:bottom-10 right-6 lg:right-10 z-50 max-w-xs bg-slate-900 text-white rounded-3xl p-6 shadow-2xl border border-white/10"
    >
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center flex-shrink-0">
          <Download className="w-6 h-6 text-indigo-400" />
        </div>
        <div className="flex-1">
          <h4 className="font-black uppercase tracking-tight text-sm">Deploy HR FLOW</h4>
          <p className="text-[10px] text-slate-400 font-bold leading-relaxed uppercase mt-1">Install to home screen for native enterprise experience.</p>
          <div className="flex items-center gap-3 mt-4">
            <button 
              onClick={handleInstall}
              className="px-4 py-2 bg-indigo-600 text-white rounded-xl font-black text-[9px] uppercase tracking-widest shadow-lg shadow-indigo-900/40"
            >
              Install Now
            </button>
            <button 
              onClick={() => setIsVisible(false)}
              className="px-4 py-2 bg-white/5 text-slate-400 rounded-xl font-black text-[9px] uppercase tracking-widest hover:text-white"
            >
              Later
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const Layout = ({ children }: { children: React.ReactNode }) => {
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const { profile } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/login');
  };

  const getPageTitle = () => {
    const path = location.pathname;
    if (path === '/admin') return 'Admin Dashboard';
    if (path === '/hr') return 'Organization Overview';
    if (path.includes('employees')) return 'Team Directory';
    if (path.includes('attendance')) return 'Time Tracker';
    if (path.includes('leaves')) return 'Leave Control';
    if (path.includes('reports')) return 'Data Reports';
    return 'Dashboard';
  };

  return (
    <div className="flex min-h-screen bg-slate-50/30 overflow-x-hidden">
      {/* Sidebar Desktop */}
      <aside className="hidden lg:flex w-[280px] bg-white border-r border-slate-100 flex-col h-screen sticky top-0 overflow-hidden">
        <div className="flex flex-col h-full">
          <div className="p-8">
            <div className="flex items-center gap-3 mb-12">
              <div className="w-10 h-10 bg-slate-900 rounded-xl flex items-center justify-center text-white shadow-2xl shadow-slate-200">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-base font-black tracking-tighter text-slate-900 leading-none">HR FLOW</h1>
                <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mt-1">v.2.4 Premium</p>
              </div>
            </div>
            <Navigation />
          </div>

          <div className="mt-auto p-6 sm:p-8 bg-slate-50/50 border-t border-slate-100 italic font-medium">
             <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-black text-sm shadow-lg ring-4 ring-white">
                  {profile?.name?.[0] || 'U'}
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-black text-slate-900 truncate uppercase tracking-tight">{profile?.name}</p>
                  <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{profile?.role}</p>
                </div>
             </div>
            <button 
              onClick={handleLogout}
              className="w-full flex items-center justify-center gap-2 group py-3.5 bg-white border border-slate-200 rounded-2xl text-slate-400 hover:text-rose-600 hover:border-rose-100 hover:bg-rose-50 transition-all font-black text-[10px] uppercase tracking-widest shadow-sm active:scale-95"
            >
              <LogOut className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
              <span>Detach Terminal</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSidebarOpen(false)}
              className="fixed inset-0 bg-slate-900/40 backdrop-blur-md z-40 lg:hidden"
            />
            <motion.aside 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-y-4 left-4 w-[300px] bg-white z-50 lg:hidden flex flex-col shadow-2xl rounded-[2.5rem] border border-slate-100 overflow-hidden"
            >
              <div className="p-8 flex-1 overflow-y-auto">
                <div className="flex items-center justify-between mb-10">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-slate-900 rounded-xl flex items-center justify-center text-white shadow-lg">
                      <Building2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h1 className="text-lg font-black tracking-tighter text-slate-900 leading-none">HR FLOW</h1>
                      <p className="text-[8px] font-bold text-slate-400 uppercase tracking-tighter">Enterprise Suite</p>
                    </div>
                  </div>
                  <button onClick={() => setSidebarOpen(false)} className="p-2.5 text-slate-400 hover:bg-slate-50 rounded-xl border border-slate-50 transition-colors">
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <Navigation closeMenu={() => setSidebarOpen(false)} />
              </div>

              <div className="p-8 border-t border-slate-50 bg-slate-50/50">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-black text-sm shadow-lg ring-2 ring-white">
                    {profile?.name?.[0] || 'U'}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-black text-slate-900 truncate">{profile?.name}</p>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{profile?.role}</p>
                  </div>
                </div>
                <button 
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 px-4 py-3.5 text-rose-600 hover:bg-white hover:shadow-sm border border-transparent hover:border-rose-100 rounded-xl transition-all font-black text-xs uppercase tracking-widest"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign Out</span>
                </button>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-20 glass border-b border-slate-100 flex items-center justify-between px-6 lg:px-10 sticky top-0 z-30">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setSidebarOpen(true)}
              className="p-3 text-slate-600 bg-white border border-slate-100 shadow-sm rounded-2xl lg:hidden hover:bg-slate-50 active:scale-95 transition-all"
            >
              <Menu className="w-6 h-6" />
            </button>
            <div className="hidden sm:block">
              <div className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-0.5">
                <span>System</span>
                <ChevronRight className="w-3 h-3 text-slate-300" />
                <span className="text-slate-900">{profile?.role === 'hr' ? 'Ops Center' : 'Root'}</span>
              </div>
              <h2 className="text-sm font-black text-slate-900 tracking-tight uppercase">{getPageTitle()}</h2>
            </div>
          </div>

          <div className="flex items-center gap-3 lg:gap-6">
            <div className="hidden md:flex items-center gap-2 bg-slate-50 border border-slate-100 rounded-xl px-4 py-2.5 text-slate-400 focus-within:ring-4 focus-within:ring-slate-100 focus-within:border-slate-200 transition-all">
              <Search className="w-4 h-4" />
              <input type="text" placeholder="Search system..." className="bg-transparent border-none outline-none text-[11px] font-bold text-slate-900 w-40 placeholder:text-slate-300" />
            </div>
            
            <button className="relative p-2.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all border border-transparent hover:border-indigo-100">
              <Bell className="w-5 h-5" />
              <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-indigo-500 rounded-full ring-2 ring-white"></span>
            </button>
            
            <div className="w-px h-8 bg-slate-100 hidden sm:block"></div>
            
            <div className="flex items-center gap-3 pl-2">
              <div className="text-right hidden sm:block">
                <p className="text-[11px] font-black text-slate-900 leading-none uppercase">{profile?.name}</p>
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1">Verified Node</p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center p-0.5 group cursor-pointer overflow-hidden transition-all hover:scale-105 active:scale-95">
                <div className="w-full h-full rounded-[10px] bg-slate-900 text-white flex items-center justify-center font-black text-xs uppercase">
                  {profile?.name?.[0] || 'U'}
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-6 lg:p-10 pb-28 lg:pb-10">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          >
            {children}
          </motion.div>
        </main>
        <BottomNav />
      </div>
    </div>
  );
};

const PrivateRoute = ({ children, allowedRoles }: { children: React.ReactNode, allowedRoles?: string[] }) => {
  const { user, profile, loading } = useAuth();
  
  if (loading) return (
    <div className="h-screen w-full flex flex-col items-center justify-center bg-white">
      <motion.div 
        animate={{ scale: [1, 1.1, 1], opacity: [0.5, 1, 0.5] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-2xl shadow-indigo-100 mb-6"
      >
        <Building2 className="w-8 h-8" />
      </motion.div>
      <div className="w-48 h-1 bg-slate-100 rounded-full overflow-hidden">
        <motion.div 
          initial={{ x: '-100%' }}
          animate={{ x: '100%' }}
          transition={{ repeat: Infinity, duration: 1.5, ease: 'easeInOut' }}
          className="w-full h-full bg-indigo-600"
        />
      </div>
    </div>
  );

  if (!user) return <Navigate to="/login" />;
  if (allowedRoles && profile && !allowedRoles.includes(profile.role)) return <Navigate to="/" />;
  
  return (
    <Layout>
      {children}
    </Layout>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Suspense fallback={<PageLoader />}>
          <AnimatePresence mode="wait">
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/request" element={<RegistrationRequestPage />} />
              
              {/* Admin Routes */}
              <Route path="/admin" element={
                <PrivateRoute allowedRoles={['super_admin']}>
                  <AdminDashboard />
                </PrivateRoute>
              } />
              <Route path="/admin/organizations" element={
                <PrivateRoute allowedRoles={['super_admin']}>
                  <AdminDashboard /> 
                </PrivateRoute>
              } />

              {/* HR Routes */}
              <Route path="/hr" element={
                <PrivateRoute allowedRoles={['hr']}>
                  <HRDashboard />
                </PrivateRoute>
              } />
              <Route path="/hr/employees" element={
                <PrivateRoute allowedRoles={['hr']}>
                  <EmployeeList />
                </PrivateRoute>
              } />
              <Route path="/hr/attendance" element={
                <PrivateRoute allowedRoles={['hr']}>
                  <AttendancePage />
                </PrivateRoute>
              } />
              <Route path="/hr/leaves" element={
                <PrivateRoute allowedRoles={['hr']}>
                  <LeaveManagement />
                </PrivateRoute>
              } />
              <Route path="/hr/reports" element={
                <PrivateRoute allowedRoles={['hr']}>
                  <ReportsPage />
                </PrivateRoute>
              } />
              <Route path="/settings" element={
                <PrivateRoute>
                  <Settings />
                </PrivateRoute>
              } />

              <Route path="/" element={<HomeRedirect />} />
            </Routes>
          </AnimatePresence>
        </Suspense>
      </Router>
    </AuthProvider>
  );
}

const HomeRedirect = () => {
  const { profile, loading } = useAuth();
  if (loading) return null;
  if (!profile) return <Navigate to="/login" />;
  if (profile.role === 'super_admin') return <Navigate to="/admin" />;
  if (profile.role === 'hr') return <Navigate to="/hr" />;
  return <Navigate to="/login" />;
}

